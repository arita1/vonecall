<?php if (!defined('FW')) {
    die('Forbidden');
}

/**
 * @var array $atts
 */
?>
<?php echo do_shortcode('[smartslider3 slider=' . $atts['id'] . ']'); ?>