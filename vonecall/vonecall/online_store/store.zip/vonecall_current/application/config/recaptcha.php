<?php

// To use reCAPTCHA, you need to sign up for an API key pair for your site.
// link: http://www.google.com/recaptcha/admin
$config['recaptcha_site_key'] = '6LcgYQgUAAAAACqND5lTKW28zNx5vlB8CxwNyXRb';
$config['recaptcha_secret_key'] = '6LcgYQgUAAAAAASzXBb4IzrIJ3tMsHk5AHWkqBZf';

// reCAPTCHA supported 40+ languages listed here:
// https://developers.google.com/recaptcha/docs/language
$config['recaptcha_lang'] = 'en';

/* End of file recaptcha.php */
/* Location: ./application/config/recaptcha.php */
