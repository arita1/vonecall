<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Authorize.net Account Info
$config['api_login_id'] = '8G6x4wuAa4';
$config['api_transaction_key'] ='3479M472evS4VDjU';
$config['api_url'] = 'https://test.authorize.net/gateway/transact.dll'; // TEST URL
//$config['api_url'] = 'https://secure.authorize.net/gateway/transact.dll'; // PRODUCTION URL

/* EOF */


//API Login ID: 	637bMYv8AR4
//Current Transaction Key: 	492FLCw8cckV3X34