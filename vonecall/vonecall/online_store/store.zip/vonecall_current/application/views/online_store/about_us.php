<?php $this->load->view('online_store/inc_header');?>
<!-- slider -->
			<div id="main-slider" class="slider">
	    		
				  <div><img src="images/slider/img1.jpg" title="" /></div>
				 
			</div>	
	<!-- /slider -->

<!-- content -->


<div class="content">
<div class="box-table my-account">
			  <div class="panel-group" id="accordion">
				<div class="panel panel-default">
				  <div class="panel-heading">
					<h4 class="panel-title">
					  <a class="accordion-toggle" >
						About Us
					  </a>
					</h4>
				  </div>
				  <div id="collapseOne" class="panel-collapse collapse in">
					<div class="panel-body">
					<p>Vone Call is an international calling service offering calls to over 300 countries across the world at low calling rates.
From call quality to customer service, Vone Call gives you the ultimate international calling experience at the most affordable rates.
</p>
<p>
Vone Call offers best call rates international calls to any phone number across the world . Join the Vone Call  now and experience truly world class time tested and proven service embraced by many customers.
We are providing you the best features in managing your International pinless calling accounts. No longer bound to a retail store, you can recharge your mobile phone from any computer or smart phone, as well as manage your shared numbers, update your speed dial contacts, and search for the best International rates around..
</p>


					</div>
				  </div>
				</div>

				
				</div>
</div>
</div>
<?php $this->load->view('online_store/inc_footer');?>



