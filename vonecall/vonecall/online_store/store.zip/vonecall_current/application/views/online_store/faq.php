<?php $this->load->view('online_store/inc_header');?>


	<!-- slider -->
			<div id="main-slider" class="slider">
				  <div><img src="images/slider/img3.jpg" title="" /></div>
			</div>	
	<!-- /slider -->

<!-- content -->
<div class="content">

    <!-- /.intro-header -->
		
	<div class="how-it-work">
			<div class="container">		
				<div class="title"><h3>FAQ</h3></div>
			  <div class="panel-group" id="accordion">
				<div class="panel panel-default">
				  <div class="panel-heading">
					<h4 class="panel-title">
					  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
						Question 
					  </a>
					</h4>
				  </div>
				  <div id="collapseOne" class="panel-collapse collapse in">
					<div class="panel-body">
					  Donec dapibus turpis enim, vel tincidunt eros sagittis at. Proin volutpat facilisis malesuada. Nunc sodales pharetra tincidunt. Sed id congue lectus. Mauris ultrices lobortis nibh, in porttitor est. Pellentesque malesuada pharetra pellentesque. Morbi convallis massa non metus fringilla, at malesuada purus rhoncus. 
					</div>
				  </div>
				</div>
				<div class="panel panel-default">
				  <div class="panel-heading">
					<h4 class="panel-title">
					  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
						Question
					  </a>
					</h4>
				  </div>
				  <div id="collapseTwo" class="panel-collapse collapse">
					<div class="panel-body">
					  Donec dapibus turpis enim, vel tincidunt eros sagittis at. Proin volutpat facilisis malesuada. Nunc sodales pharetra tincidunt. Sed id congue lectus. Mauris ultrices lobortis nibh, in porttitor est. Pellentesque malesuada pharetra pellentesque. Morbi convallis massa non metus fringilla, at malesuada purus rhoncus. 
					</div>
				  </div>
				</div>
				<div class="panel panel-default">
				  <div class="panel-heading">
					<h4 class="panel-title">
					  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
						Question
					  </a>
					</h4>
				  </div>
				  <div id="collapseThree" class="panel-collapse collapse">
					<div class="panel-body">
					  Donec dapibus turpis enim, vel tincidunt eros sagittis at. Proin volutpat facilisis malesuada. Nunc sodales pharetra tincidunt. Sed id congue lectus. Mauris ultrices lobortis nibh, in porttitor est. Pellentesque malesuada pharetra pellentesque. Morbi convallis massa non metus fringilla, at malesuada purus rhoncus. 
					</div>
				  </div>
				</div>
				<div class="panel panel-default">
				  <div class="panel-heading">
					<h4 class="panel-title">
					  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
						Question
					  </a>
					</h4>
				  </div>
				  <div id="collapseThree" class="panel-collapse collapse">
					<div class="panel-body">
					  Donec dapibus turpis enim, vel tincidunt eros sagittis at. Proin volutpat facilisis malesuada. Nunc sodales pharetra tincidunt. Sed id congue lectus. Mauris ultrices lobortis nibh, in porttitor est. Pellentesque malesuada pharetra pellentesque. Morbi convallis massa non metus fringilla, at malesuada purus rhoncus. 
					</div>
				  </div>
				</div>
			  </div>
			</div>
		</div>
	</div>
   
    <!-- /.content-section-a -->

<?php $this->load->view('online_store/inc_footer');?>



