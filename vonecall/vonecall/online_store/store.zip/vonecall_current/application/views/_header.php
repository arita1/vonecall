<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->lang->line('header_title');?></title>
<link href="<?php echo $this->config->item('base_url')?>public/css/style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->config->item('base_url')?>public/css/colorbox.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->config->item('base_url')?>public/css/jquery.datetimepicker.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->config->item('base_url')?>public/css/dataTables.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" charset="utf-8" src="<?php echo $this->config->item('base_url')?>public/js/jquery.1.11.1.js"></script>
<script type="text/javascript" charset="utf-8" src="<?php echo $this->config->item('base_url')?>public/js/combobox.js"></script>
<script type="text/javascript" charset="utf-8" src="<?php echo $this->config->item('base_url')?>public/js/jquery.colorbox.js"></script>
<script type="text/javascript" charset="utf-8" src="<?php echo $this->config->item('base_url')?>public/js/jquery.datetimepicker.js"></script>
<script type="text/javascript" charset="utf-8" src="<?php echo $this->config->item('base_url')?>public/js/phone.js"></script>
<script type="text/javascript" charset="utf-8" src="<?php echo $this->config->item('base_url')?>public/js/jquery.validate.js"></script>
<script type="text/javascript" charset="utf-8" src="<?php echo $this->config->item('base_url')?>public/js/jquery.dataTables.js"></script>
<!-- javascript coding -->
<script type="text/javascript">
$(document).ready(function(){
  $("#choose").click(function () {
    $(".choose_lang1").slideToggle();
    $(".choose_lang2").slideToggle();
  });
  $("#nav_main li").hover(
    function () {
      $(this).addClass("hover");
    },
    function () {
      $(this).removeClass("hover");
    }
  );      
});
function set_language(lang) {
  $.post("<?php echo site_url('index/language');?>/"+lang, {},
      function(data) {
      window.location.reload();
      }
    );
}

function send_email(emailTo){
  
  $.colorbox({ href: "<?php echo site_url('email-us');?>/"+emailTo, width: "800px", height: "400px", iframe: true, scrolling: true });

}
</script>
<?php if ($this->session->userdata('language')=='spanish') {?>
<style>
.contact_line {width: 458px;}
</style>
<?php }?>
</head>
<body>
  
<div id="page_margins">
  <div id="container">
  <div id="header">
    <div class="w322 float_left p12t"><a href="<?php echo site_url();?>"><img src="<?php echo $this->config->item('base_url')?>public/images/logo.png" style="width: 245px;"/></a></div>
    <div class="float_right">
      <div class="box_singup"><span><a href="<?php echo site_url('logout');?>"><?php echo $this->lang->line('logout');?></a></span></div>
      <div class="menu_reseller_login font15"><?php echo $this->lang->line('welcome');?> <span class="yellow_color"><?php echo $this->session->userdata('store_username');?></span></div>
      <div class="cb"></div>
      <div class="float_right  p20t">
        <!-- Contact Phone Number line -->        
        <div class="laguage_show float_right"><a href="javascript:void(0);" id="choose"><?php echo $this->lang->line('lang_title');?></a>
          <div class="choose_lang1" onclick="set_language('<?php echo $this->lang->line('lang_key1');?>');"><?php echo $this->lang->line('lang_title1');?></div>
        </div>       
        <div class="float_left p10r p6t">
          <img src="<?php echo $this->config->item('base_url')?>public/images/icon_phone.png" alt="" class="float_left p10r"/>
            <div class="contact_line"><?php echo $this->lang->line('customer_services_24hr');?>:<span class="red_color"><strong> <?php echo format_phone_number($this->session->userdata('header_contact'))?></strong></span></div>
        </div>
        <!-- Contact Phone Number line END -->
        
        <div class="show" style="margin-top: 35px !important;">
          <!-- Contact With Email -->
          <select style="float: right; margin-right: 0; width: 138px;" onchange="send_email(this.value)">
            <option value="">-- Email To --</option>
            <option value="1">Distributor</option>
            <option value="2">Customer Service</option>
          </select>
                 
          <div class="float_right p10r p6t" style="width: 110px;">
            <img src="<?php echo $this->config->item('base_url')?>public/images/email_icon.png" alt="" class="float_left p10r" width="24px"/>
              <div class="contact_line_email">Email Us:<span class="red_color"><strong>  </strong></span></div>
          </div>
        <!-- Contact With Email END -->
        </div>
      </div>
    </div>
    <div class="cb"></div>
  </div>
  <div id="nav_top">
    <div id="nav_main">
      <div class="nav_home"><a href="<?php echo site_url('home');?>"><img src="<?php echo $this->config->item('base_url')?>public/images/icon_home.png"/></a></div>
      <ul>
        <li <?php if($current_page=='pinless') echo 'class="current"';?>> <a href="<?php echo site_url('pinless');?>"> <?php echo $this->lang->line('pinless');?></a> </li>       
      <!--   <li <?php // if($current_page=='topup') echo 'class="current"';?>><a href="javascript:void(0);"><span><?php// echo $this->lang->line('topup');?></span></a>
          <ul class="nav-2">
       <li><a href="<?php //echo site_url('topup');?>"><?php //echo $this->lang->line('international_top');?></a></li> 
            <li><a href="<?php //echo site_url('topup-usa-rtr');?>"><?php //echo $this->lang->line('usa_rtr');?></a></li>
            <li><a href="<?php //echo site_url('topup-usa-pin');?>"><?php //echo $this->lang->line('usa_pin');?></a></li>
          </ul>
        </li> -->
      <!--   <li <?php //if($current_page=='calling_card') echo 'class="current"';?>><a href="javascript:void(0);"><span><?php //echo $this->lang->line('calling_card');?></span></a>
          <ul class="nav-2">
            <li><a href="<?php //echo site_url('buy-calling-card');?>"><?php //echo $this->lang->line('buy_calling_card');?></a></li>
            <li><a href="<?php //echo site_url('calling-card-history');?>"><?php //echo $this->lang->line('calling_card_history');?></a></li>
            <li><a href="<?php //echo site_url('calling-card-rate-sheet');?>"><?php //echo $this->lang->line('calling_card_rate');?></a></li>
          </ul>
        </li> -->
        <li <?php if($current_page=='report') echo 'class="current"';?>><a href="javascript:void(0);"> <span> <?php echo $this->lang->line('reports');?> </span> </a>
          <ul class="nav-2">
            <li><a href="<?php echo site_url('sales-report');?>"><?php echo $this->lang->line('sales_report');?></a></li>
            <li><a href="<?php echo site_url('commission-report');?>"><?php echo $this->lang->line('commission_report');?></a></li>
            <li><a href="<?php echo site_url('payment-report');?>"><?php echo $this->lang->line('payment_report');?></a></li>
            <li><a href="<?php echo site_url('product-list');?>"><?php echo $this->lang->line('product_list');?></a></li>
            <li><a href="<?php echo site_url('pinless-access-number');?>" class='popupBox'> Pinless Access Numbers </a></li>
            <li><a href="<?php echo site_url('pinless-rate');?>" class='popupBox' > Pinless Rate Sheet </a></li>
            <li><a href="<?php echo site_url('pinless-call-history');?>" class='popupBox'> Pinless Call History </a></li> 
            <li><a href="<?php echo site_url('pinless-activity');?>" class='popupBox'> <?php echo $this->lang->line('pinless_activity');?> </a></li>
            <li><a href="<?php echo site_url('usa-pin-activity');?>" class='popupBox'> <?php echo $this->lang->line('usa-pin_activity');?> </a></li>
          </ul>
        </li>        
        <li <?php if($current_page=='payment') echo 'class="current"';?>><a href="javascript:void(0);"> <span> <?php echo $this->lang->line('payment');?> </span> </a>
          <ul class="nav-2">
            <li><a href="<?php echo site_url('balance');?>"><?php echo $this->lang->line('store_balance');?></a></li>
            <li><a href="<?php echo site_url('payment');?>"><?php echo $this->lang->line('fund_account');?></a></li>
            <li><a href="<?php echo site_url('refund');?>"><?php echo $this->lang->line('request_refund');?></a></li>
               <li><a href="<?php echo site_url('remove');?>"><?php echo $this->lang->line('remove_cards');?></a></li>
          </ul>
        </li>
        <li <?php if($current_page=='admin') echo 'class="current"';?>><a href="javascript:void(0);"> <span> <?php echo $this->lang->line('admin');?> </span> </a>
          <ul class="nav-2">
            <li><a href="<?php echo site_url('update-password');?>"><?php echo $this->lang->line('update_password');?></a></li>
          </ul>
        </li>
        <?php if($this->session->userdata('redirect')){ ?>
          <!-- <li style="width: 150px;"><a href="<?php echo site_url('return-to-admin');?>"> Return To Admin </a> </li>      -->
        <?php } ?>
      </ul>
    </div>
    <div class="cb"></div>
  </div>
  <div id="page">