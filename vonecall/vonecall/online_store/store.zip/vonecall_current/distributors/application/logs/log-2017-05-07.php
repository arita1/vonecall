<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-05-07 23:45:27 --> Config Class Initialized
DEBUG - 2017-05-07 23:45:27 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:45:27 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:45:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:45:28 --> URI Class Initialized
DEBUG - 2017-05-07 23:45:28 --> Router Class Initialized
DEBUG - 2017-05-07 23:45:28 --> Output Class Initialized
DEBUG - 2017-05-07 23:45:28 --> Security Class Initialized
DEBUG - 2017-05-07 23:45:28 --> Input Class Initialized
DEBUG - 2017-05-07 23:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:45:28 --> Language Class Initialized
DEBUG - 2017-05-07 23:45:28 --> Loader Class Initialized
DEBUG - 2017-05-07 23:45:28 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:45:28 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:45:28 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:45:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:45:28 --> Session Class Initialized
DEBUG - 2017-05-07 23:45:28 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:45:28 --> Session routines successfully run
DEBUG - 2017-05-07 23:45:28 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:45:28 --> Controller Class Initialized
DEBUG - 2017-05-07 23:45:28 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:45:28 --> Model Class Initialized
DEBUG - 2017-05-07 23:45:28 --> Model Class Initialized
DEBUG - 2017-05-07 23:45:28 --> File loaded: application/views/login.php
DEBUG - 2017-05-07 23:45:28 --> Final output sent to browser
DEBUG - 2017-05-07 23:45:28 --> Total execution time: 0.5713
DEBUG - 2017-05-07 23:49:29 --> Config Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:49:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:49:29 --> URI Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Router Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Output Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Security Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Input Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:49:29 --> Language Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Loader Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:49:29 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:49:29 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:49:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:49:29 --> Session Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:49:29 --> Session routines successfully run
DEBUG - 2017-05-07 23:49:29 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Controller Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:49:29 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Config Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:49:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:49:29 --> URI Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Router Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Output Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Security Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Input Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:49:29 --> Language Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Loader Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:49:29 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:49:29 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:49:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:49:29 --> Session Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:49:29 --> Session routines successfully run
DEBUG - 2017-05-07 23:49:29 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Controller Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-07 23:49:29 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:49:29 --> Helper loaded: format_helper
DEBUG - 2017-05-07 23:49:29 --> Form Validation Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:29 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:30 --> File loaded: application/views/home.php
DEBUG - 2017-05-07 23:49:30 --> Final output sent to browser
DEBUG - 2017-05-07 23:49:30 --> Total execution time: 0.4638
DEBUG - 2017-05-07 23:49:30 --> Config Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:49:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:49:30 --> URI Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Router Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Output Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Security Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Input Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:49:30 --> Language Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Loader Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:49:30 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:49:30 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:49:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:49:30 --> Session Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:49:30 --> Session routines successfully run
DEBUG - 2017-05-07 23:49:30 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Controller Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-07 23:49:30 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:49:30 --> Helper loaded: format_helper
DEBUG - 2017-05-07 23:49:30 --> Form Validation Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:30 --> Final output sent to browser
DEBUG - 2017-05-07 23:49:30 --> Total execution time: 0.2743
DEBUG - 2017-05-07 23:49:33 --> Config Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:49:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:49:33 --> URI Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Router Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Output Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Security Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Input Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:49:33 --> Language Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Loader Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:49:33 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:49:33 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:49:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:49:33 --> Session Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:49:33 --> Session routines successfully run
DEBUG - 2017-05-07 23:49:33 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Controller Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-07 23:49:33 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:49:33 --> Helper loaded: format_helper
DEBUG - 2017-05-07 23:49:33 --> Form Validation Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:33 --> Final output sent to browser
DEBUG - 2017-05-07 23:49:33 --> Total execution time: 0.2505
DEBUG - 2017-05-07 23:49:34 --> Config Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:49:34 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:49:34 --> URI Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Router Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Output Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Security Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Input Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:49:34 --> Language Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Loader Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:49:34 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:49:34 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:49:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:49:34 --> Session Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:49:34 --> Session routines successfully run
DEBUG - 2017-05-07 23:49:34 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Controller Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-07 23:49:34 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:49:34 --> Helper loaded: format_helper
DEBUG - 2017-05-07 23:49:34 --> Form Validation Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:34 --> Final output sent to browser
DEBUG - 2017-05-07 23:49:34 --> Total execution time: 0.2546
DEBUG - 2017-05-07 23:49:35 --> Config Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:49:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:49:35 --> URI Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Router Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Output Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Security Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Input Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:49:35 --> Language Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Loader Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:49:35 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:49:35 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:49:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:49:35 --> Session Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:49:35 --> Session routines successfully run
DEBUG - 2017-05-07 23:49:35 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Controller Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-07 23:49:35 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:49:35 --> Helper loaded: format_helper
DEBUG - 2017-05-07 23:49:35 --> Form Validation Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:35 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:36 --> Final output sent to browser
DEBUG - 2017-05-07 23:49:36 --> Total execution time: 0.2687
DEBUG - 2017-05-07 23:49:38 --> Config Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:49:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:49:38 --> URI Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Router Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Output Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Security Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Input Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:49:38 --> Language Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Loader Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:49:38 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:49:38 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:49:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:49:38 --> Session Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:49:38 --> Session routines successfully run
DEBUG - 2017-05-07 23:49:38 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Controller Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-07 23:49:38 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:49:38 --> Helper loaded: format_helper
DEBUG - 2017-05-07 23:49:38 --> Form Validation Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:38 --> Final output sent to browser
DEBUG - 2017-05-07 23:49:38 --> Total execution time: 0.2524
DEBUG - 2017-05-07 23:49:39 --> Config Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:49:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:49:39 --> URI Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Router Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Output Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Security Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Input Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:49:39 --> Language Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Loader Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:49:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:49:39 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:49:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:49:39 --> Session Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:49:39 --> Session routines successfully run
DEBUG - 2017-05-07 23:49:39 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Controller Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-07 23:49:39 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:49:39 --> Helper loaded: format_helper
DEBUG - 2017-05-07 23:49:39 --> Form Validation Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:39 --> Final output sent to browser
DEBUG - 2017-05-07 23:49:39 --> Total execution time: 0.2508
DEBUG - 2017-05-07 23:49:40 --> Config Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:49:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:49:41 --> URI Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Router Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Output Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Security Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Input Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:49:41 --> Language Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Loader Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:49:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:49:41 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:49:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:49:41 --> Session Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:49:41 --> Session routines successfully run
DEBUG - 2017-05-07 23:49:41 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Controller Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-07 23:49:41 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:49:41 --> Helper loaded: format_helper
DEBUG - 2017-05-07 23:49:41 --> Form Validation Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:41 --> Final output sent to browser
DEBUG - 2017-05-07 23:49:41 --> Total execution time: 0.2545
DEBUG - 2017-05-07 23:49:42 --> Config Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:49:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:49:42 --> URI Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Router Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Output Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Security Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Input Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:49:42 --> Language Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Loader Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:49:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:49:42 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:49:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:49:42 --> Session Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:49:42 --> Session routines successfully run
DEBUG - 2017-05-07 23:49:42 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Controller Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-07 23:49:42 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:49:42 --> Helper loaded: format_helper
DEBUG - 2017-05-07 23:49:42 --> Form Validation Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Model Class Initialized
DEBUG - 2017-05-07 23:49:42 --> Final output sent to browser
DEBUG - 2017-05-07 23:49:42 --> Total execution time: 0.2543
DEBUG - 2017-05-07 23:56:15 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:15 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:15 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:15 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:15 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:15 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:15 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:15 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:15 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-07 23:56:15 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:15 --> Helper loaded: format_helper
DEBUG - 2017-05-07 23:56:15 --> Form Validation Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:15 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:15 --> File loaded: application/views/home.php
DEBUG - 2017-05-07 23:56:15 --> Final output sent to browser
DEBUG - 2017-05-07 23:56:15 --> Total execution time: 0.2888
DEBUG - 2017-05-07 23:56:16 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:16 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:16 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:16 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:16 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:16 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:16 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:16 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:16 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-07 23:56:16 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:16 --> Helper loaded: format_helper
DEBUG - 2017-05-07 23:56:16 --> Form Validation Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:16 --> Final output sent to browser
DEBUG - 2017-05-07 23:56:16 --> Total execution time: 0.2660
DEBUG - 2017-05-07 23:56:26 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:26 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:26 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:26 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:26 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:26 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:26 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:26 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:26 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:26 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:26 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:26 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:26 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:26 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:26 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:26 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:26 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:26 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:26 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:26 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:26 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:26 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:26 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:26 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:26 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:27 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:27 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:27 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:27 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:27 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:27 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:27 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:27 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:27 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:27 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:27 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:27 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:27 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:27 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:27 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:27 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:27 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:27 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:27 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:27 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:27 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:27 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:27 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:27 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:27 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:27 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:27 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:27 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:27 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:27 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:27 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:27 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:27 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:27 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:27 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:27 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:27 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:27 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:27 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:27 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:27 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:27 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:27 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:27 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:27 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:27 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:27 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:27 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:27 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:27 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:27 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:27 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:27 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:27 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:27 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:27 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:27 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:27 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:27 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:27 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:28 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:28 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:28 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:28 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:28 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:28 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:28 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:28 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:28 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:28 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:28 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:28 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:28 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:28 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:28 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:28 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:28 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:28 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:28 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:28 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:28 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:28 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:28 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:28 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:28 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:28 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:28 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:28 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:28 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:28 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:28 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:28 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:28 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:28 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:28 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:28 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:28 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:28 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:28 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:28 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:28 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:28 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:28 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:28 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:28 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:28 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:28 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:28 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:28 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:28 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:28 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:28 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:28 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:28 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:29 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:29 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:29 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:29 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:29 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:29 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:29 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:29 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:29 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:29 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:29 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:29 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:29 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:29 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:29 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:29 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:29 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:29 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:29 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:29 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:29 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:29 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:29 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:29 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:29 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:29 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:29 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:29 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:29 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:29 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:29 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:29 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:29 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:29 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:29 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:29 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:29 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:29 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:29 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:29 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:29 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:29 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:29 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:29 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:29 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:29 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:29 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:29 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:29 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:29 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:29 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:29 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:29 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:29 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:30 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:30 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:30 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:30 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:30 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:30 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:30 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:30 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:30 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:30 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:30 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:30 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:30 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:30 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:30 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:30 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:30 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:30 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:30 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:30 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:30 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:30 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:30 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:30 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:30 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:30 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:30 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:30 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:30 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:30 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:30 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:30 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:30 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:30 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:30 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:30 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:30 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:30 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:30 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:30 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:30 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:30 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:30 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:30 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:30 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:30 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:30 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:30 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:31 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:31 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:31 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:31 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:31 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:31 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:31 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:31 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:31 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:31 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:31 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:31 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:31 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:31 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:31 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:31 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:31 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:31 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:31 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:31 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:31 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:31 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:31 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:31 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:31 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:31 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:31 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:31 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:31 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:31 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:31 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:31 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:31 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:31 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:31 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:31 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:31 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:31 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:31 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:31 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:31 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:31 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:31 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:31 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:31 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:31 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:31 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:31 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:31 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:31 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:31 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:31 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:31 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:31 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:31 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:32 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:32 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:32 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:32 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:32 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:32 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:32 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:32 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:32 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:32 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:32 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:32 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:32 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:32 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:32 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:32 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:32 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:32 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:32 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:32 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:32 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:32 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:32 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:32 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:32 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:32 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:32 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:32 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:32 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:32 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:32 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:32 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:32 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:32 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:32 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:32 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:32 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:32 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:32 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:32 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:32 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:32 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:32 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:32 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:32 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:32 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:32 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:32 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:32 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:32 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:32 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:32 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:32 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:32 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:32 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:32 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:32 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:32 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:32 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:33 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:33 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:33 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:33 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:33 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:33 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:33 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:33 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:33 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:33 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:33 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:33 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:33 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:33 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:33 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:33 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:33 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:33 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:33 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:33 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:33 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:33 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:33 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:33 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:33 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:33 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:33 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:33 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:33 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:33 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:33 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:33 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:33 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:33 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:33 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:33 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:33 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:33 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:33 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:33 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:33 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:33 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:33 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:33 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:33 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:33 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:33 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:33 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:33 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:34 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:34 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:34 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:34 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:34 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:34 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:34 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:34 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:34 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:34 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:34 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:34 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:34 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:34 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:34 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:34 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:34 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:34 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:34 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:39 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:39 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:39 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:39 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:39 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:39 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:39 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:39 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:39 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:39 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:39 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:39 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:39 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:39 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:39 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:39 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:39 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:39 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:39 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:39 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:39 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:39 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:39 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:39 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:39 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:39 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:39 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:39 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:39 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:39 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:39 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:39 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:40 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:40 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:40 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:40 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:40 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:40 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:40 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:40 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:40 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:40 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:40 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:40 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:40 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:40 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:40 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:40 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:40 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:40 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:40 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:40 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:40 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:40 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:40 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:40 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:40 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:40 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:40 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:40 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:40 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:40 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:40 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:40 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:40 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:40 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:40 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:40 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:40 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:40 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:40 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:40 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:40 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:40 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:40 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:40 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:40 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:40 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:40 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:40 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:40 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:40 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:40 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:40 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:40 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:40 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:40 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:41 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:41 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:41 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:41 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:41 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:41 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:41 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:41 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:41 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:41 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:41 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:41 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:41 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:41 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:41 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:41 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:41 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:41 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:41 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:41 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:41 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:41 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:41 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:41 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:41 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:41 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:41 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:41 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:41 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:41 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:41 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:41 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:41 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:41 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:41 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:41 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:41 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:41 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:41 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:41 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:41 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:42 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:42 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:42 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:42 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:42 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:42 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:42 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:42 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:42 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:42 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:42 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:42 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:42 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:42 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:42 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:42 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:42 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:42 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:42 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:42 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:42 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:42 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:42 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:42 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:42 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:42 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:42 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:42 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:42 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:42 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:42 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:42 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:42 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:42 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:42 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:42 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:42 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:42 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:42 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:42 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:42 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:42 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:42 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:42 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:43 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:43 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:43 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:43 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:43 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:43 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:43 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:43 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:43 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:43 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:43 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:43 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Config Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:56:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:56:43 --> URI Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Router Class Initialized
DEBUG - 2017-05-07 23:56:43 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:56:43 --> Output Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Security Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Input Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:56:43 --> Language Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Loader Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:56:43 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:56:43 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:56:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:56:43 --> Session Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:56:43 --> Session routines successfully run
DEBUG - 2017-05-07 23:56:43 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Controller Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:56:43 --> Model Class Initialized
DEBUG - 2017-05-07 23:56:43 --> Model Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Config Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:57:13 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:57:13 --> URI Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Router Class Initialized
DEBUG - 2017-05-07 23:57:13 --> No URI present. Default controller set.
DEBUG - 2017-05-07 23:57:13 --> Output Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Security Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Input Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:57:13 --> Language Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Loader Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:57:13 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:57:13 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:57:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:57:13 --> Session Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:57:13 --> Session routines successfully run
DEBUG - 2017-05-07 23:57:13 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Controller Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:57:13 --> Model Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Model Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Config Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:57:13 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:57:13 --> URI Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Router Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Output Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Security Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Input Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:57:13 --> Language Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Loader Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:57:13 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:57:13 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:57:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:57:13 --> Session Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:57:13 --> Session routines successfully run
DEBUG - 2017-05-07 23:57:13 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Controller Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-07 23:57:13 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:57:13 --> Helper loaded: format_helper
DEBUG - 2017-05-07 23:57:13 --> Form Validation Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Model Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Model Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Model Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Model Class Initialized
DEBUG - 2017-05-07 23:57:13 --> Model Class Initialized
DEBUG - 2017-05-07 23:57:14 --> File loaded: application/views/home.php
DEBUG - 2017-05-07 23:57:14 --> Final output sent to browser
DEBUG - 2017-05-07 23:57:14 --> Total execution time: 0.3029
DEBUG - 2017-05-07 23:57:14 --> Config Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Hooks Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Utf8 Class Initialized
DEBUG - 2017-05-07 23:57:14 --> UTF-8 Support Enabled
DEBUG - 2017-05-07 23:57:14 --> URI Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Router Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Output Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Security Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Input Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-07 23:57:14 --> Language Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Loader Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Helper loaded: url_helper
DEBUG - 2017-05-07 23:57:14 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-07 23:57:14 --> Database Driver Class Initialized
ERROR - 2017-05-07 23:57:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-07 23:57:14 --> Session Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Helper loaded: string_helper
DEBUG - 2017-05-07 23:57:14 --> Session routines successfully run
DEBUG - 2017-05-07 23:57:14 --> User Agent Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Controller Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-07 23:57:14 --> Helper loaded: form_helper
DEBUG - 2017-05-07 23:57:14 --> Helper loaded: format_helper
DEBUG - 2017-05-07 23:57:14 --> Form Validation Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Model Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Model Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Model Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Model Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Model Class Initialized
DEBUG - 2017-05-07 23:57:14 --> Final output sent to browser
DEBUG - 2017-05-07 23:57:14 --> Total execution time: 0.3190
