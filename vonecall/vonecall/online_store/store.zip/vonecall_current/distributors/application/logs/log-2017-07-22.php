<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-07-22 05:24:38 --> Config Class Initialized
DEBUG - 2017-07-22 05:24:38 --> Hooks Class Initialized
DEBUG - 2017-07-22 05:24:38 --> Utf8 Class Initialized
DEBUG - 2017-07-22 05:24:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-22 05:24:38 --> URI Class Initialized
DEBUG - 2017-07-22 05:24:38 --> Router Class Initialized
DEBUG - 2017-07-22 05:24:38 --> No URI present. Default controller set.
DEBUG - 2017-07-22 05:24:38 --> Output Class Initialized
DEBUG - 2017-07-22 05:24:38 --> Security Class Initialized
DEBUG - 2017-07-22 05:24:38 --> Input Class Initialized
DEBUG - 2017-07-22 05:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-22 05:24:38 --> Language Class Initialized
DEBUG - 2017-07-22 05:24:38 --> Loader Class Initialized
DEBUG - 2017-07-22 05:24:38 --> Helper loaded: url_helper
DEBUG - 2017-07-22 05:24:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-07-22 05:24:39 --> Database Driver Class Initialized
ERROR - 2017-07-22 05:24:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-07-22 05:24:39 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-07-22 05:24:39 --> Unable to connect to the database
DEBUG - 2017-07-22 05:24:39 --> Session Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Helper loaded: string_helper
DEBUG - 2017-07-22 05:24:39 --> Session routines successfully run
DEBUG - 2017-07-22 05:24:39 --> User Agent Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Controller Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Helper loaded: form_helper
DEBUG - 2017-07-22 05:24:39 --> Model Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Model Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Config Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Hooks Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Utf8 Class Initialized
DEBUG - 2017-07-22 05:24:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-22 05:24:39 --> URI Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Router Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Output Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Security Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Input Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-22 05:24:39 --> Language Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Loader Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Helper loaded: url_helper
DEBUG - 2017-07-22 05:24:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-07-22 05:24:39 --> Database Driver Class Initialized
ERROR - 2017-07-22 05:24:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-07-22 05:24:39 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-07-22 05:24:39 --> Unable to connect to the database
DEBUG - 2017-07-22 05:24:39 --> Session Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Helper loaded: string_helper
DEBUG - 2017-07-22 05:24:39 --> Session routines successfully run
DEBUG - 2017-07-22 05:24:39 --> User Agent Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Controller Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Helper loaded: form_helper
DEBUG - 2017-07-22 05:24:39 --> Model Class Initialized
DEBUG - 2017-07-22 05:24:39 --> Model Class Initialized
DEBUG - 2017-07-22 05:24:39 --> File loaded: application/views/login.php
DEBUG - 2017-07-22 05:24:39 --> Final output sent to browser
DEBUG - 2017-07-22 05:24:39 --> Total execution time: 0.0730
