<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-05-08 00:25:09 --> Config Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:25:09 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:25:09 --> URI Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Router Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Output Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Security Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Input Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:25:09 --> Language Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Loader Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:25:09 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:25:09 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:25:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:25:09 --> Session Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:25:09 --> Session routines successfully run
DEBUG - 2017-05-08 00:25:09 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Controller Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:25:09 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:25:09 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:25:09 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:09 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:09 --> File loaded: application/views/home.php
DEBUG - 2017-05-08 00:25:09 --> Final output sent to browser
DEBUG - 2017-05-08 00:25:10 --> Total execution time: 0.2767
DEBUG - 2017-05-08 00:25:10 --> Config Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:25:10 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:25:10 --> URI Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Router Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Output Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Security Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Input Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:25:10 --> Language Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Loader Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:25:10 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:25:10 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:25:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:25:10 --> Session Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:25:10 --> Session routines successfully run
DEBUG - 2017-05-08 00:25:10 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Controller Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:25:10 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:25:10 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:25:10 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:10 --> Final output sent to browser
DEBUG - 2017-05-08 00:25:10 --> Total execution time: 0.2358
DEBUG - 2017-05-08 00:25:28 --> Config Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:25:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:25:28 --> URI Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Router Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Output Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Security Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Input Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:25:28 --> Language Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Loader Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:25:28 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:25:28 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:25:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:25:28 --> Session Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:25:28 --> Session routines successfully run
DEBUG - 2017-05-08 00:25:28 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Controller Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:25:28 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:25:28 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:25:28 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:28 --> File loaded: application/views/home.php
DEBUG - 2017-05-08 00:25:28 --> Final output sent to browser
DEBUG - 2017-05-08 00:25:28 --> Total execution time: 0.2636
DEBUG - 2017-05-08 00:25:28 --> Config Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:25:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:25:28 --> URI Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Router Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Output Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Security Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Input Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:25:28 --> Language Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Loader Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:25:28 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:25:28 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:25:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:25:28 --> Session Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:25:28 --> Session routines successfully run
DEBUG - 2017-05-08 00:25:28 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Controller Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:25:28 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:25:28 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:25:28 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:28 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:29 --> Model Class Initialized
DEBUG - 2017-05-08 00:25:29 --> Final output sent to browser
DEBUG - 2017-05-08 00:25:29 --> Total execution time: 0.2748
DEBUG - 2017-05-08 00:26:44 --> Config Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:26:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:26:44 --> URI Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Router Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Output Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Security Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Input Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:26:44 --> Language Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Loader Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:26:44 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:26:44 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:26:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:26:44 --> Session Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:26:44 --> Session routines successfully run
DEBUG - 2017-05-08 00:26:44 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Controller Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:26:44 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:26:44 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:26:44 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Model Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Model Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Model Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Model Class Initialized
DEBUG - 2017-05-08 00:26:44 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Config Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:27:07 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:27:07 --> URI Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Router Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Output Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Security Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Input Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:27:07 --> Language Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Loader Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:27:07 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:27:07 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:27:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:27:07 --> Session Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:27:07 --> Session routines successfully run
DEBUG - 2017-05-08 00:27:07 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Controller Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:27:07 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:27:07 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:27:07 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:07 --> Model Class Initialized
ERROR - 2017-05-08 00:27:07 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in C:\xampp\htdocs\vonecall\distributors\application\controllers\agent.php on line 32 and defined C:\xampp\htdocs\vonecall\distributors\system\libraries\Session.php 428
ERROR - 2017-05-08 00:27:07 --> Severity: Notice  --> Undefined variable: item C:\xampp\htdocs\vonecall\distributors\system\libraries\Session.php 430
DEBUG - 2017-05-08 00:27:15 --> Config Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:27:15 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:27:15 --> URI Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Router Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Output Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Security Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Input Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:27:15 --> Language Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Loader Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:27:15 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:27:15 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:27:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:27:15 --> Session Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:27:15 --> Session routines successfully run
DEBUG - 2017-05-08 00:27:15 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Controller Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:27:15 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:27:15 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:27:15 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:15 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Config Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:27:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:27:27 --> URI Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Router Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Output Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Security Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Input Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:27:27 --> Language Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Loader Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:27:27 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:27:27 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:27:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:27:27 --> Session Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:27:27 --> Session routines successfully run
DEBUG - 2017-05-08 00:27:27 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Controller Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:27:27 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:27:27 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:27:27 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:27 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Config Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:27:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:27:49 --> URI Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Router Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Output Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Security Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Input Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:27:49 --> Language Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Loader Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:27:49 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:27:49 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:27:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:27:49 --> Session Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:27:49 --> Session routines successfully run
DEBUG - 2017-05-08 00:27:49 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Controller Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:27:49 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:27:49 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:27:49 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:49 --> File loaded: application/views/home.php
DEBUG - 2017-05-08 00:27:49 --> Final output sent to browser
DEBUG - 2017-05-08 00:27:49 --> Total execution time: 0.2724
DEBUG - 2017-05-08 00:27:49 --> Config Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:27:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:27:49 --> URI Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Router Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Output Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Security Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Input Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:27:49 --> Language Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Loader Class Initialized
DEBUG - 2017-05-08 00:27:49 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:27:49 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:27:50 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:27:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:27:50 --> Session Class Initialized
DEBUG - 2017-05-08 00:27:50 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:27:50 --> Session routines successfully run
DEBUG - 2017-05-08 00:27:50 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:27:50 --> Controller Class Initialized
DEBUG - 2017-05-08 00:27:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:27:50 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:27:50 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:27:50 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:27:50 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:50 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:50 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:50 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:50 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:50 --> Final output sent to browser
DEBUG - 2017-05-08 00:27:50 --> Total execution time: 0.2725
DEBUG - 2017-05-08 00:27:53 --> Config Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:27:53 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:27:53 --> URI Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Router Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Output Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Security Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Input Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:27:53 --> Language Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Loader Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:27:53 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:27:53 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:27:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:27:53 --> Session Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:27:53 --> Session routines successfully run
DEBUG - 2017-05-08 00:27:53 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Controller Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:27:53 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:27:53 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:27:53 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Model Class Initialized
DEBUG - 2017-05-08 00:27:53 --> Final output sent to browser
DEBUG - 2017-05-08 00:27:53 --> Total execution time: 0.2644
DEBUG - 2017-05-08 00:29:09 --> Config Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:29:09 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:29:09 --> URI Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Router Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Output Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Security Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Input Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:29:09 --> Language Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Loader Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:29:09 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:29:09 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:29:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:29:09 --> Session Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:29:09 --> Session routines successfully run
DEBUG - 2017-05-08 00:29:09 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Controller Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:29:09 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:29:09 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:29:09 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Model Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Model Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Model Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Model Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Model Class Initialized
DEBUG - 2017-05-08 00:29:09 --> Final output sent to browser
DEBUG - 2017-05-08 00:29:09 --> Total execution time: 0.2600
DEBUG - 2017-05-08 00:29:59 --> Config Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:29:59 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:29:59 --> URI Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Router Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Output Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Security Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Input Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:29:59 --> Language Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Loader Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:29:59 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:29:59 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:29:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:29:59 --> Session Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:29:59 --> Session routines successfully run
DEBUG - 2017-05-08 00:29:59 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Controller Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:29:59 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:29:59 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:29:59 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Model Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Model Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Model Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Model Class Initialized
DEBUG - 2017-05-08 00:29:59 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:00 --> Final output sent to browser
DEBUG - 2017-05-08 00:30:00 --> Total execution time: 0.2557
DEBUG - 2017-05-08 00:30:37 --> Config Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:30:37 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:30:37 --> URI Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Router Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Output Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Security Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Input Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:30:37 --> Language Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Loader Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:30:37 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:30:37 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:30:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:30:37 --> Session Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:30:37 --> Session routines successfully run
DEBUG - 2017-05-08 00:30:37 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Controller Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:30:37 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:30:37 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:30:37 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:37 --> File loaded: application/views/home.php
DEBUG - 2017-05-08 00:30:37 --> Final output sent to browser
DEBUG - 2017-05-08 00:30:37 --> Total execution time: 0.3005
DEBUG - 2017-05-08 00:30:37 --> Config Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:30:37 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:30:37 --> URI Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Router Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Output Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Security Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Input Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:30:37 --> Language Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Loader Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:30:37 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:30:37 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:30:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:30:37 --> Session Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:30:37 --> Session routines successfully run
DEBUG - 2017-05-08 00:30:37 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Controller Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:30:37 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:30:37 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:30:37 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:37 --> Final output sent to browser
DEBUG - 2017-05-08 00:30:37 --> Total execution time: 0.3207
DEBUG - 2017-05-08 00:30:39 --> Config Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:30:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:30:39 --> URI Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Router Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Output Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Security Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Input Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:30:39 --> Language Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Loader Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:30:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:30:39 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:30:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:30:39 --> Session Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:30:39 --> Session routines successfully run
DEBUG - 2017-05-08 00:30:39 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Controller Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:30:39 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:30:39 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:30:39 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Model Class Initialized
DEBUG - 2017-05-08 00:30:39 --> Final output sent to browser
DEBUG - 2017-05-08 00:30:39 --> Total execution time: 0.2771
DEBUG - 2017-05-08 00:51:11 --> Config Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:51:11 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:51:11 --> URI Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Router Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Output Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Security Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Input Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:51:11 --> Language Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Loader Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:51:11 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:51:11 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:51:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:51:11 --> Session Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:51:11 --> Session routines successfully run
DEBUG - 2017-05-08 00:51:11 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Controller Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:51:11 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:51:11 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:51:11 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Model Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Model Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Model Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Model Class Initialized
DEBUG - 2017-05-08 00:51:11 --> Model Class Initialized
DEBUG - 2017-05-08 00:51:11 --> File loaded: application/views/add_new_account_subdist.php
DEBUG - 2017-05-08 00:51:11 --> Final output sent to browser
DEBUG - 2017-05-08 00:51:11 --> Total execution time: 0.2425
DEBUG - 2017-05-08 00:51:30 --> Config Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:51:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:51:30 --> URI Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Router Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Output Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Security Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Input Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:51:30 --> Language Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Loader Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:51:30 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:51:30 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:51:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:51:30 --> Session Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:51:30 --> Session routines successfully run
DEBUG - 2017-05-08 00:51:30 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Controller Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:51:30 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:51:30 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:51:30 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Model Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Model Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Model Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Model Class Initialized
DEBUG - 2017-05-08 00:51:30 --> Model Class Initialized
DEBUG - 2017-05-08 00:51:30 --> File loaded: application/views/sub_distributor_manager.php
DEBUG - 2017-05-08 00:51:30 --> Final output sent to browser
DEBUG - 2017-05-08 00:51:30 --> Total execution time: 0.2407
DEBUG - 2017-05-08 00:52:01 --> Config Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:52:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:52:01 --> URI Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Router Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Output Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Security Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Input Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:52:01 --> Language Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Loader Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:52:01 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:52:01 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:52:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:52:01 --> Session Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:52:01 --> Session routines successfully run
DEBUG - 2017-05-08 00:52:01 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Controller Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:52:01 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:52:01 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:52:01 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:01 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:01 --> File loaded: application/views/sub_distributor_manager.php
DEBUG - 2017-05-08 00:52:01 --> Final output sent to browser
DEBUG - 2017-05-08 00:52:01 --> Total execution time: 0.2137
DEBUG - 2017-05-08 00:52:05 --> Config Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:52:05 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:52:05 --> URI Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Router Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Output Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Security Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Input Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:52:05 --> Language Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Loader Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:52:05 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:52:05 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:52:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:52:05 --> Session Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:52:05 --> Session routines successfully run
DEBUG - 2017-05-08 00:52:05 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Controller Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:52:05 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:52:05 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:52:05 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:05 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:05 --> File loaded: application/views/distributor/_distributor.php
DEBUG - 2017-05-08 00:52:05 --> Final output sent to browser
DEBUG - 2017-05-08 00:52:05 --> Total execution time: 0.2852
DEBUG - 2017-05-08 00:52:49 --> Config Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:52:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:52:49 --> URI Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Router Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Output Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Security Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Input Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:52:49 --> Language Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Loader Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:52:49 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:52:49 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:52:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:52:49 --> Session Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:52:49 --> Session routines successfully run
DEBUG - 2017-05-08 00:52:49 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Controller Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:52:49 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:52:49 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:52:49 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:49 --> File loaded: application/views/distributor/_distributor.php
DEBUG - 2017-05-08 00:52:49 --> Final output sent to browser
DEBUG - 2017-05-08 00:52:49 --> Total execution time: 0.2924
DEBUG - 2017-05-08 00:52:54 --> Config Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:52:54 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:52:54 --> URI Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Router Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Output Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Security Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Input Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:52:54 --> Language Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Loader Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:52:54 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:52:54 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:52:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:52:54 --> Session Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:52:54 --> Session routines successfully run
DEBUG - 2017-05-08 00:52:54 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Controller Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:52:54 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:52:54 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:52:54 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:54 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:54 --> File loaded: application/views/sub_distributor_store_manager.php
DEBUG - 2017-05-08 00:52:54 --> Final output sent to browser
DEBUG - 2017-05-08 00:52:54 --> Total execution time: 0.2406
DEBUG - 2017-05-08 00:52:58 --> Config Class Initialized
DEBUG - 2017-05-08 00:52:58 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:52:58 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:52:58 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:52:59 --> URI Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Router Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Output Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Security Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Input Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:52:59 --> Language Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Loader Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:52:59 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:52:59 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:52:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:52:59 --> Session Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:52:59 --> Session routines successfully run
DEBUG - 2017-05-08 00:52:59 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Controller Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:52:59 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:52:59 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:52:59 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Model Class Initialized
DEBUG - 2017-05-08 00:52:59 --> Model Class Initialized
ERROR - 2017-05-08 00:52:59 --> Severity: Notice  --> Undefined variable: results C:\xampp\htdocs\vonecall\distributors\application\controllers\agent.php 971
DEBUG - 2017-05-08 00:52:59 --> File loaded: application/views/sub_distributor_store_manager.php
DEBUG - 2017-05-08 00:52:59 --> Final output sent to browser
DEBUG - 2017-05-08 00:52:59 --> Total execution time: 0.2285
DEBUG - 2017-05-08 00:53:06 --> Config Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:53:06 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:53:06 --> URI Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Router Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Output Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Security Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Input Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:53:06 --> Language Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Loader Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:53:06 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:53:06 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:53:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:53:06 --> Session Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:53:06 --> Session routines successfully run
DEBUG - 2017-05-08 00:53:06 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Controller Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:53:06 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:53:06 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:53:06 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Model Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Model Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Model Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Model Class Initialized
DEBUG - 2017-05-08 00:53:06 --> Model Class Initialized
DEBUG - 2017-05-08 00:53:06 --> File loaded: application/views/sub_distributor_store_manager.php
DEBUG - 2017-05-08 00:53:06 --> Final output sent to browser
DEBUG - 2017-05-08 00:53:06 --> Total execution time: 0.2168
DEBUG - 2017-05-08 00:53:22 --> Config Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:53:22 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:53:22 --> URI Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Router Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Output Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Security Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Input Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:53:22 --> Language Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Loader Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:53:22 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:53:22 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:53:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:53:22 --> Session Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:53:22 --> Session routines successfully run
DEBUG - 2017-05-08 00:53:22 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Controller Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:53:22 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:53:22 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:53:22 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Model Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Model Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Model Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Model Class Initialized
DEBUG - 2017-05-08 00:53:22 --> Model Class Initialized
DEBUG - 2017-05-08 00:53:22 --> File loaded: application/views/add_new_agent.php
DEBUG - 2017-05-08 00:53:22 --> Final output sent to browser
DEBUG - 2017-05-08 00:53:22 --> Total execution time: 0.2274
DEBUG - 2017-05-08 00:54:04 --> Config Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:54:04 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:54:04 --> URI Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Router Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Output Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Security Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Input Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:54:04 --> Language Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Loader Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:54:04 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:54:04 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:54:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:54:04 --> Session Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:54:04 --> Session routines successfully run
DEBUG - 2017-05-08 00:54:04 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Controller Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:54:04 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:54:04 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:54:04 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:04 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:04 --> File loaded: application/views/agent_account_manager.php
DEBUG - 2017-05-08 00:54:04 --> Final output sent to browser
DEBUG - 2017-05-08 00:54:04 --> Total execution time: 0.2220
DEBUG - 2017-05-08 00:54:08 --> Config Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:54:08 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:54:08 --> URI Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Router Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Output Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Security Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Input Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:54:08 --> Language Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Loader Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:54:08 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:54:08 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:54:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:54:08 --> Session Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:54:08 --> Session routines successfully run
DEBUG - 2017-05-08 00:54:08 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Controller Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:54:08 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:54:08 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:54:08 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:08 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:08 --> File loaded: application/views/add_new_agent.php
DEBUG - 2017-05-08 00:54:08 --> Final output sent to browser
DEBUG - 2017-05-08 00:54:08 --> Total execution time: 0.2167
DEBUG - 2017-05-08 00:54:46 --> Config Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:54:46 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:54:46 --> URI Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Router Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Output Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Security Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Input Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:54:46 --> Language Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Loader Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:54:46 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:54:46 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:54:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:54:46 --> Session Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:54:46 --> Session routines successfully run
DEBUG - 2017-05-08 00:54:46 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Controller Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:54:46 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:54:46 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:54:46 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:46 --> Model Class Initialized
ERROR - 2017-05-08 00:54:46 --> Severity: Notice  --> Undefined variable: option_subdist C:\xampp\htdocs\vonecall\distributors\application\views\reports\sales_report.php 38
ERROR - 2017-05-08 00:54:46 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vonecall\distributors\system\helpers\form_helper.php 331
DEBUG - 2017-05-08 00:54:46 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 00:54:46 --> Final output sent to browser
DEBUG - 2017-05-08 00:54:46 --> Total execution time: 0.2600
DEBUG - 2017-05-08 00:54:48 --> Config Class Initialized
DEBUG - 2017-05-08 00:54:48 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:54:48 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:54:48 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:54:48 --> URI Class Initialized
DEBUG - 2017-05-08 00:54:48 --> Router Class Initialized
DEBUG - 2017-05-08 00:54:48 --> Output Class Initialized
DEBUG - 2017-05-08 00:54:48 --> Security Class Initialized
DEBUG - 2017-05-08 00:54:48 --> Input Class Initialized
DEBUG - 2017-05-08 00:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:54:48 --> Language Class Initialized
DEBUG - 2017-05-08 00:54:48 --> Loader Class Initialized
DEBUG - 2017-05-08 00:54:48 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:54:48 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:54:48 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:54:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:54:48 --> Session Class Initialized
DEBUG - 2017-05-08 00:54:49 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:54:49 --> Session routines successfully run
DEBUG - 2017-05-08 00:54:49 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:54:49 --> Controller Class Initialized
DEBUG - 2017-05-08 00:54:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:54:49 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:54:49 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:54:49 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:54:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:49 --> Model Class Initialized
ERROR - 2017-05-08 00:54:49 --> Severity: Notice  --> Undefined variable: option_subdist C:\xampp\htdocs\vonecall\distributors\application\views\reports\sales_report.php 38
ERROR - 2017-05-08 00:54:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vonecall\distributors\system\helpers\form_helper.php 331
DEBUG - 2017-05-08 00:54:49 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 00:54:49 --> Final output sent to browser
DEBUG - 2017-05-08 00:54:49 --> Total execution time: 0.4144
DEBUG - 2017-05-08 00:54:52 --> Config Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:54:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:54:52 --> URI Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Router Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Output Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Security Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Input Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:54:52 --> Language Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Loader Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:54:52 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:54:52 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:54:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:54:52 --> Session Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:54:52 --> Session routines successfully run
DEBUG - 2017-05-08 00:54:52 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Controller Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:54:52 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:54:52 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:54:52 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:52 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:52 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 00:54:52 --> Final output sent to browser
DEBUG - 2017-05-08 00:54:52 --> Total execution time: 0.2320
DEBUG - 2017-05-08 00:54:54 --> Config Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:54:54 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:54:54 --> URI Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Router Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Output Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Security Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Input Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:54:54 --> Language Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Loader Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:54:54 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:54:54 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:54:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:54:54 --> Session Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:54:54 --> Session routines successfully run
DEBUG - 2017-05-08 00:54:54 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Controller Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:54:54 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:54:54 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:54:54 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:54 --> Model Class Initialized
DEBUG - 2017-05-08 00:54:54 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 00:54:54 --> Final output sent to browser
DEBUG - 2017-05-08 00:54:54 --> Total execution time: 0.4025
DEBUG - 2017-05-08 00:54:59 --> Config Class Initialized
DEBUG - 2017-05-08 00:54:59 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:54:59 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:55:00 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:55:00 --> URI Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Router Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Output Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Security Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Input Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:55:00 --> Language Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Loader Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:55:00 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:55:00 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:55:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:55:00 --> Session Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:55:00 --> Session routines successfully run
DEBUG - 2017-05-08 00:55:00 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Controller Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:55:00 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:55:00 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:55:00 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Model Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Model Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Model Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Model Class Initialized
DEBUG - 2017-05-08 00:55:00 --> Model Class Initialized
DEBUG - 2017-05-08 00:55:00 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 00:55:00 --> Final output sent to browser
DEBUG - 2017-05-08 00:55:00 --> Total execution time: 0.4000
DEBUG - 2017-05-08 00:55:36 --> Config Class Initialized
DEBUG - 2017-05-08 00:55:36 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:55:36 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:55:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:55:36 --> URI Class Initialized
DEBUG - 2017-05-08 00:55:36 --> Router Class Initialized
DEBUG - 2017-05-08 00:55:36 --> Output Class Initialized
DEBUG - 2017-05-08 00:55:36 --> Security Class Initialized
DEBUG - 2017-05-08 00:55:36 --> Input Class Initialized
DEBUG - 2017-05-08 00:55:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:55:36 --> Language Class Initialized
DEBUG - 2017-05-08 00:55:36 --> Loader Class Initialized
DEBUG - 2017-05-08 00:55:37 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:55:37 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:55:37 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:55:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:55:37 --> Session Class Initialized
DEBUG - 2017-05-08 00:55:37 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:55:37 --> Session routines successfully run
DEBUG - 2017-05-08 00:55:37 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:55:37 --> Controller Class Initialized
DEBUG - 2017-05-08 00:55:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:55:37 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:55:37 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:55:37 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:55:37 --> Model Class Initialized
DEBUG - 2017-05-08 00:55:37 --> Model Class Initialized
DEBUG - 2017-05-08 00:55:37 --> Model Class Initialized
DEBUG - 2017-05-08 00:55:37 --> Model Class Initialized
DEBUG - 2017-05-08 00:55:37 --> Model Class Initialized
ERROR - 2017-05-08 00:55:37 --> Could not find the language line "header_title"
ERROR - 2017-05-08 00:55:37 --> Could not find the language line "country_code"
ERROR - 2017-05-08 00:55:37 --> Could not find the language line "balance"
DEBUG - 2017-05-08 00:55:37 --> File loaded: application/views/popup_rate.php
DEBUG - 2017-05-08 00:55:37 --> Final output sent to browser
DEBUG - 2017-05-08 00:55:37 --> Total execution time: 0.2792
DEBUG - 2017-05-08 00:55:49 --> Config Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:55:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:55:49 --> URI Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Router Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Output Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Security Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Input Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:55:49 --> Language Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Loader Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:55:49 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:55:49 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:55:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:55:49 --> Session Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:55:49 --> Session routines successfully run
DEBUG - 2017-05-08 00:55:49 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Controller Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:55:49 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:55:49 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:55:49 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:55:49 --> Model Class Initialized
DEBUG - 2017-05-08 00:55:49 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 00:55:49 --> Final output sent to browser
DEBUG - 2017-05-08 00:55:49 --> Total execution time: 0.2344
DEBUG - 2017-05-08 00:56:07 --> Config Class Initialized
DEBUG - 2017-05-08 00:56:07 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:56:07 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:56:07 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:56:08 --> URI Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Router Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Output Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Security Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Input Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:56:08 --> Language Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Loader Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:56:08 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:56:08 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:56:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:56:08 --> Session Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:56:08 --> Session routines successfully run
DEBUG - 2017-05-08 00:56:08 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Controller Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:56:08 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:56:08 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:56:08 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:08 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:08 --> File loaded: application/views/agent_account_manager.php
DEBUG - 2017-05-08 00:56:08 --> Final output sent to browser
DEBUG - 2017-05-08 00:56:08 --> Total execution time: 0.2651
DEBUG - 2017-05-08 00:56:14 --> Config Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:56:14 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:56:14 --> URI Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Router Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Output Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Security Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Input Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:56:14 --> Language Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Loader Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:56:14 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:56:14 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:56:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:56:14 --> Session Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:56:14 --> Session routines successfully run
DEBUG - 2017-05-08 00:56:14 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Controller Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:56:14 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:56:14 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:56:14 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:14 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:14 --> File loaded: application/views/agent_account_manager.php
DEBUG - 2017-05-08 00:56:14 --> Final output sent to browser
DEBUG - 2017-05-08 00:56:14 --> Total execution time: 0.2130
DEBUG - 2017-05-08 00:56:18 --> Config Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:56:18 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:56:18 --> URI Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Router Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Output Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Security Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Input Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:56:18 --> Language Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Loader Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:56:18 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:56:18 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:56:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:56:18 --> Session Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:56:18 --> Session routines successfully run
DEBUG - 2017-05-08 00:56:18 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Controller Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:56:18 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:56:18 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:56:18 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:18 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:18 --> File loaded: application/views/agent_account_manager.php
DEBUG - 2017-05-08 00:56:18 --> Final output sent to browser
DEBUG - 2017-05-08 00:56:18 --> Total execution time: 0.2289
DEBUG - 2017-05-08 00:56:21 --> Config Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:56:21 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:56:21 --> URI Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Router Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Output Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Security Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Input Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:56:21 --> Language Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Loader Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:56:21 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:56:21 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:56:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:56:21 --> Session Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:56:21 --> Session routines successfully run
DEBUG - 2017-05-08 00:56:21 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Controller Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:56:21 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:56:21 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:56:21 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:21 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:21 --> File loaded: application/views/agent_account_manager.php
DEBUG - 2017-05-08 00:56:21 --> Final output sent to browser
DEBUG - 2017-05-08 00:56:21 --> Total execution time: 0.2274
DEBUG - 2017-05-08 00:56:22 --> Config Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:56:22 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:56:22 --> URI Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Router Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Output Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Security Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Input Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:56:22 --> Language Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Loader Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:56:22 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:56:22 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:56:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:56:22 --> Session Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:56:22 --> Session routines successfully run
DEBUG - 2017-05-08 00:56:22 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Controller Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:56:22 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:56:22 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:56:22 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:22 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:22 --> File loaded: application/views/agent_account_manager.php
DEBUG - 2017-05-08 00:56:22 --> Final output sent to browser
DEBUG - 2017-05-08 00:56:22 --> Total execution time: 0.2218
DEBUG - 2017-05-08 00:56:24 --> Config Class Initialized
DEBUG - 2017-05-08 00:56:24 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:56:24 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:56:24 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:56:24 --> URI Class Initialized
DEBUG - 2017-05-08 00:56:24 --> Router Class Initialized
DEBUG - 2017-05-08 00:56:25 --> Output Class Initialized
DEBUG - 2017-05-08 00:56:25 --> Security Class Initialized
DEBUG - 2017-05-08 00:56:25 --> Input Class Initialized
DEBUG - 2017-05-08 00:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:56:25 --> Language Class Initialized
DEBUG - 2017-05-08 00:56:25 --> Loader Class Initialized
DEBUG - 2017-05-08 00:56:25 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:56:25 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:56:25 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:56:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:56:25 --> Session Class Initialized
DEBUG - 2017-05-08 00:56:25 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:56:25 --> Session routines successfully run
DEBUG - 2017-05-08 00:56:25 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:56:25 --> Controller Class Initialized
DEBUG - 2017-05-08 00:56:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:56:25 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:56:25 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:56:25 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:56:25 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:25 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:25 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:25 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:25 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:25 --> File loaded: application/views/agent_account_manager.php
DEBUG - 2017-05-08 00:56:25 --> Final output sent to browser
DEBUG - 2017-05-08 00:56:25 --> Total execution time: 0.2313
DEBUG - 2017-05-08 00:56:30 --> Config Class Initialized
DEBUG - 2017-05-08 00:56:30 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:56:30 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:56:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:56:30 --> URI Class Initialized
DEBUG - 2017-05-08 00:56:30 --> Router Class Initialized
DEBUG - 2017-05-08 00:56:30 --> Output Class Initialized
DEBUG - 2017-05-08 00:56:30 --> Security Class Initialized
DEBUG - 2017-05-08 00:56:30 --> Input Class Initialized
DEBUG - 2017-05-08 00:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:56:30 --> Language Class Initialized
DEBUG - 2017-05-08 00:56:30 --> Loader Class Initialized
DEBUG - 2017-05-08 00:56:30 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:56:30 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:56:30 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:56:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:56:30 --> Session Class Initialized
DEBUG - 2017-05-08 00:56:31 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:56:31 --> Session routines successfully run
DEBUG - 2017-05-08 00:56:31 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:56:31 --> Controller Class Initialized
DEBUG - 2017-05-08 00:56:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:56:31 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:56:31 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:56:31 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:56:31 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:31 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:31 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:31 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:31 --> Model Class Initialized
ERROR - 2017-05-08 00:56:31 --> Severity: Notice  --> Undefined variable: option_subdist C:\xampp\htdocs\vonecall\distributors\application\views\reports\sales_report.php 38
ERROR - 2017-05-08 00:56:31 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vonecall\distributors\system\helpers\form_helper.php 331
DEBUG - 2017-05-08 00:56:31 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 00:56:31 --> Final output sent to browser
DEBUG - 2017-05-08 00:56:31 --> Total execution time: 0.2562
DEBUG - 2017-05-08 00:56:38 --> Config Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:56:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:56:38 --> URI Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Router Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Output Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Security Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Input Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:56:38 --> Language Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Loader Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:56:38 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:56:38 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:56:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:56:38 --> Session Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:56:38 --> Session routines successfully run
DEBUG - 2017-05-08 00:56:38 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Controller Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:56:38 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:56:38 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:56:38 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:38 --> Model Class Initialized
DEBUG - 2017-05-08 00:56:38 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 00:56:38 --> Final output sent to browser
DEBUG - 2017-05-08 00:56:38 --> Total execution time: 0.4222
DEBUG - 2017-05-08 00:58:00 --> Config Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:58:00 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:58:00 --> URI Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Router Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Output Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Security Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Input Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:58:00 --> Language Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Loader Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:58:00 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:58:00 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:58:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:58:00 --> Session Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:58:00 --> Session routines successfully run
DEBUG - 2017-05-08 00:58:00 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Controller Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:58:00 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:58:00 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:58:00 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:00 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:00 --> File loaded: application/views/payment.php
DEBUG - 2017-05-08 00:58:00 --> Final output sent to browser
DEBUG - 2017-05-08 00:58:00 --> Total execution time: 0.2979
DEBUG - 2017-05-08 00:58:23 --> Config Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:58:23 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:58:23 --> URI Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Router Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Output Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Security Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Input Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:58:23 --> Language Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Loader Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:58:23 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:58:23 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:58:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:58:23 --> Session Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:58:23 --> Session routines successfully run
DEBUG - 2017-05-08 00:58:23 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Controller Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:58:23 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:58:23 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:58:23 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:23 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:23 --> File loaded: application/views/payment_adjust.php
DEBUG - 2017-05-08 00:58:23 --> Final output sent to browser
DEBUG - 2017-05-08 00:58:23 --> Total execution time: 0.3057
DEBUG - 2017-05-08 00:58:39 --> Config Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:58:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:58:39 --> URI Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Router Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Output Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Security Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Input Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:58:39 --> Language Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Loader Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:58:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:58:39 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:58:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:58:39 --> Session Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:58:39 --> Session routines successfully run
DEBUG - 2017-05-08 00:58:39 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Controller Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:58:39 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:58:39 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:58:39 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:39 --> Model Class Initialized
ERROR - 2017-05-08 00:58:39 --> Severity: Notice  --> Undefined variable: option_subdist C:\xampp\htdocs\vonecall\distributors\application\views\reports\sales_report.php 38
ERROR - 2017-05-08 00:58:39 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vonecall\distributors\system\helpers\form_helper.php 331
DEBUG - 2017-05-08 00:58:39 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 00:58:39 --> Final output sent to browser
DEBUG - 2017-05-08 00:58:39 --> Total execution time: 0.2758
DEBUG - 2017-05-08 00:58:41 --> Config Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Hooks Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Utf8 Class Initialized
DEBUG - 2017-05-08 00:58:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 00:58:41 --> URI Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Router Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Output Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Security Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Input Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 00:58:41 --> Language Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Loader Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Helper loaded: url_helper
DEBUG - 2017-05-08 00:58:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 00:58:41 --> Database Driver Class Initialized
ERROR - 2017-05-08 00:58:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 00:58:41 --> Session Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Helper loaded: string_helper
DEBUG - 2017-05-08 00:58:41 --> Session routines successfully run
DEBUG - 2017-05-08 00:58:41 --> User Agent Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Controller Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 00:58:41 --> Helper loaded: form_helper
DEBUG - 2017-05-08 00:58:41 --> Helper loaded: format_helper
DEBUG - 2017-05-08 00:58:41 --> Form Validation Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:41 --> Model Class Initialized
DEBUG - 2017-05-08 00:58:41 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 00:58:41 --> Final output sent to browser
DEBUG - 2017-05-08 00:58:41 --> Total execution time: 0.4475
DEBUG - 2017-05-08 01:06:54 --> Config Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Hooks Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Utf8 Class Initialized
DEBUG - 2017-05-08 01:06:54 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 01:06:54 --> URI Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Router Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Output Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Security Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Input Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 01:06:54 --> Language Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Loader Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Helper loaded: url_helper
DEBUG - 2017-05-08 01:06:54 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 01:06:54 --> Database Driver Class Initialized
ERROR - 2017-05-08 01:06:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 01:06:54 --> Session Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Helper loaded: string_helper
DEBUG - 2017-05-08 01:06:54 --> Session routines successfully run
DEBUG - 2017-05-08 01:06:54 --> User Agent Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Controller Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 01:06:54 --> Helper loaded: form_helper
DEBUG - 2017-05-08 01:06:54 --> Helper loaded: format_helper
DEBUG - 2017-05-08 01:06:54 --> Form Validation Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Model Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Model Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Model Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Model Class Initialized
DEBUG - 2017-05-08 01:06:54 --> Model Class Initialized
ERROR - 2017-05-08 01:06:54 --> Severity: Notice  --> Undefined variable: option_subdist C:\xampp\htdocs\vonecall\distributors\application\views\reports\sales_report.php 38
ERROR - 2017-05-08 01:06:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vonecall\distributors\system\helpers\form_helper.php 331
DEBUG - 2017-05-08 01:06:54 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 01:06:54 --> Final output sent to browser
DEBUG - 2017-05-08 01:06:54 --> Total execution time: 0.2675
DEBUG - 2017-05-08 01:06:58 --> Config Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Hooks Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Utf8 Class Initialized
DEBUG - 2017-05-08 01:06:58 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 01:06:58 --> URI Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Router Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Output Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Security Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Input Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 01:06:58 --> Language Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Loader Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Helper loaded: url_helper
DEBUG - 2017-05-08 01:06:58 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 01:06:58 --> Database Driver Class Initialized
ERROR - 2017-05-08 01:06:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 01:06:58 --> Session Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Helper loaded: string_helper
DEBUG - 2017-05-08 01:06:58 --> Session routines successfully run
DEBUG - 2017-05-08 01:06:58 --> User Agent Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Controller Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 01:06:58 --> Helper loaded: form_helper
DEBUG - 2017-05-08 01:06:58 --> Helper loaded: format_helper
DEBUG - 2017-05-08 01:06:58 --> Form Validation Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Model Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Model Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Model Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Model Class Initialized
DEBUG - 2017-05-08 01:06:58 --> Model Class Initialized
ERROR - 2017-05-08 01:06:58 --> Severity: Notice  --> Undefined variable: option_subdist C:\xampp\htdocs\vonecall\distributors\application\views\reports\sales_report.php 38
ERROR - 2017-05-08 01:06:58 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vonecall\distributors\system\helpers\form_helper.php 331
DEBUG - 2017-05-08 01:06:58 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 01:06:58 --> Final output sent to browser
DEBUG - 2017-05-08 01:06:58 --> Total execution time: 0.6135
DEBUG - 2017-05-08 01:07:17 --> Config Class Initialized
DEBUG - 2017-05-08 01:07:17 --> Hooks Class Initialized
DEBUG - 2017-05-08 01:07:17 --> Utf8 Class Initialized
DEBUG - 2017-05-08 01:07:17 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 01:07:17 --> URI Class Initialized
DEBUG - 2017-05-08 01:07:17 --> Router Class Initialized
DEBUG - 2017-05-08 01:07:18 --> Output Class Initialized
DEBUG - 2017-05-08 01:07:18 --> Security Class Initialized
DEBUG - 2017-05-08 01:07:18 --> Input Class Initialized
DEBUG - 2017-05-08 01:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 01:07:18 --> Language Class Initialized
DEBUG - 2017-05-08 01:07:18 --> Loader Class Initialized
DEBUG - 2017-05-08 01:07:18 --> Helper loaded: url_helper
DEBUG - 2017-05-08 01:07:18 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 01:07:18 --> Database Driver Class Initialized
ERROR - 2017-05-08 01:07:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 01:07:18 --> Session Class Initialized
DEBUG - 2017-05-08 01:07:18 --> Helper loaded: string_helper
DEBUG - 2017-05-08 01:07:18 --> Session routines successfully run
DEBUG - 2017-05-08 01:07:18 --> User Agent Class Initialized
DEBUG - 2017-05-08 01:07:18 --> Controller Class Initialized
DEBUG - 2017-05-08 01:07:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 01:07:18 --> Helper loaded: form_helper
DEBUG - 2017-05-08 01:07:18 --> Helper loaded: format_helper
DEBUG - 2017-05-08 01:07:18 --> Form Validation Class Initialized
DEBUG - 2017-05-08 01:07:18 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:18 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:18 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:18 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:18 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:18 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 01:07:18 --> Final output sent to browser
DEBUG - 2017-05-08 01:07:18 --> Total execution time: 0.2516
DEBUG - 2017-05-08 01:07:22 --> Config Class Initialized
DEBUG - 2017-05-08 01:07:22 --> Hooks Class Initialized
DEBUG - 2017-05-08 01:07:22 --> Utf8 Class Initialized
DEBUG - 2017-05-08 01:07:22 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 01:07:22 --> URI Class Initialized
DEBUG - 2017-05-08 01:07:22 --> Router Class Initialized
DEBUG - 2017-05-08 01:07:22 --> Output Class Initialized
DEBUG - 2017-05-08 01:07:22 --> Security Class Initialized
DEBUG - 2017-05-08 01:07:22 --> Input Class Initialized
DEBUG - 2017-05-08 01:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 01:07:22 --> Language Class Initialized
DEBUG - 2017-05-08 01:07:22 --> Loader Class Initialized
DEBUG - 2017-05-08 01:07:22 --> Helper loaded: url_helper
DEBUG - 2017-05-08 01:07:22 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 01:07:22 --> Database Driver Class Initialized
ERROR - 2017-05-08 01:07:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 01:07:22 --> Session Class Initialized
DEBUG - 2017-05-08 01:07:22 --> Helper loaded: string_helper
DEBUG - 2017-05-08 01:07:22 --> Session routines successfully run
DEBUG - 2017-05-08 01:07:23 --> User Agent Class Initialized
DEBUG - 2017-05-08 01:07:23 --> Controller Class Initialized
DEBUG - 2017-05-08 01:07:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 01:07:23 --> Helper loaded: form_helper
DEBUG - 2017-05-08 01:07:23 --> Helper loaded: format_helper
DEBUG - 2017-05-08 01:07:23 --> Form Validation Class Initialized
DEBUG - 2017-05-08 01:07:23 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:23 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:23 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:23 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:23 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:23 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 01:07:23 --> Final output sent to browser
DEBUG - 2017-05-08 01:07:23 --> Total execution time: 0.4343
DEBUG - 2017-05-08 01:07:36 --> Config Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Hooks Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Utf8 Class Initialized
DEBUG - 2017-05-08 01:07:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 01:07:36 --> URI Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Router Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Output Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Security Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Input Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 01:07:36 --> Language Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Loader Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Helper loaded: url_helper
DEBUG - 2017-05-08 01:07:36 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 01:07:36 --> Database Driver Class Initialized
ERROR - 2017-05-08 01:07:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 01:07:36 --> Session Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Helper loaded: string_helper
DEBUG - 2017-05-08 01:07:36 --> Session routines successfully run
DEBUG - 2017-05-08 01:07:36 --> User Agent Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Controller Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 01:07:36 --> Helper loaded: form_helper
DEBUG - 2017-05-08 01:07:36 --> Helper loaded: format_helper
DEBUG - 2017-05-08 01:07:36 --> Form Validation Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:36 --> Model Class Initialized
ERROR - 2017-05-08 01:07:36 --> Severity: Notice  --> Undefined variable: option_subdist C:\xampp\htdocs\vonecall\distributors\application\views\reports\sales_report.php 38
ERROR - 2017-05-08 01:07:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vonecall\distributors\system\helpers\form_helper.php 331
DEBUG - 2017-05-08 01:07:36 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 01:07:36 --> Final output sent to browser
DEBUG - 2017-05-08 01:07:36 --> Total execution time: 0.2748
DEBUG - 2017-05-08 01:07:53 --> Config Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Hooks Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Utf8 Class Initialized
DEBUG - 2017-05-08 01:07:53 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 01:07:53 --> URI Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Router Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Output Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Security Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Input Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 01:07:53 --> Language Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Loader Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Helper loaded: url_helper
DEBUG - 2017-05-08 01:07:53 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 01:07:53 --> Database Driver Class Initialized
ERROR - 2017-05-08 01:07:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 01:07:53 --> Session Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Helper loaded: string_helper
DEBUG - 2017-05-08 01:07:53 --> Session routines successfully run
DEBUG - 2017-05-08 01:07:53 --> User Agent Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Controller Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 01:07:53 --> Helper loaded: form_helper
DEBUG - 2017-05-08 01:07:53 --> Helper loaded: format_helper
DEBUG - 2017-05-08 01:07:53 --> Form Validation Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Model Class Initialized
DEBUG - 2017-05-08 01:07:53 --> Model Class Initialized
ERROR - 2017-05-08 01:07:53 --> Severity: Notice  --> Undefined variable: option_subdist C:\xampp\htdocs\vonecall\distributors\application\views\reports\sales_report.php 38
ERROR - 2017-05-08 01:07:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vonecall\distributors\system\helpers\form_helper.php 331
DEBUG - 2017-05-08 01:07:53 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-08 01:07:53 --> Final output sent to browser
DEBUG - 2017-05-08 01:07:53 --> Total execution time: 0.6243
DEBUG - 2017-05-08 05:08:18 --> Config Class Initialized
DEBUG - 2017-05-08 05:08:18 --> Hooks Class Initialized
DEBUG - 2017-05-08 05:08:18 --> Utf8 Class Initialized
DEBUG - 2017-05-08 05:08:18 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 05:08:18 --> URI Class Initialized
DEBUG - 2017-05-08 05:08:18 --> Router Class Initialized
DEBUG - 2017-05-08 05:08:18 --> Output Class Initialized
DEBUG - 2017-05-08 05:08:18 --> Security Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Input Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 05:08:19 --> Language Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Loader Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Helper loaded: url_helper
DEBUG - 2017-05-08 05:08:19 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 05:08:19 --> Database Driver Class Initialized
ERROR - 2017-05-08 05:08:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 05:08:19 --> Session Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Helper loaded: string_helper
DEBUG - 2017-05-08 05:08:19 --> Session routines successfully run
DEBUG - 2017-05-08 05:08:19 --> User Agent Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Controller Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 05:08:19 --> Config Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Hooks Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Utf8 Class Initialized
DEBUG - 2017-05-08 05:08:19 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 05:08:19 --> URI Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Router Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Output Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Security Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Input Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 05:08:19 --> Language Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Loader Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Helper loaded: url_helper
DEBUG - 2017-05-08 05:08:19 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 05:08:19 --> Database Driver Class Initialized
ERROR - 2017-05-08 05:08:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 05:08:19 --> Session Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Helper loaded: string_helper
DEBUG - 2017-05-08 05:08:19 --> Session routines successfully run
DEBUG - 2017-05-08 05:08:19 --> User Agent Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Controller Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Helper loaded: form_helper
DEBUG - 2017-05-08 05:08:19 --> Model Class Initialized
DEBUG - 2017-05-08 05:08:19 --> Model Class Initialized
DEBUG - 2017-05-08 05:08:19 --> File loaded: application/views/login.php
DEBUG - 2017-05-08 05:08:19 --> Final output sent to browser
DEBUG - 2017-05-08 05:08:19 --> Total execution time: 0.2123
DEBUG - 2017-05-08 05:08:30 --> Config Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Hooks Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Utf8 Class Initialized
DEBUG - 2017-05-08 05:08:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 05:08:30 --> URI Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Router Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Output Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Security Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Input Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 05:08:30 --> Language Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Loader Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Helper loaded: url_helper
DEBUG - 2017-05-08 05:08:30 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 05:08:30 --> Database Driver Class Initialized
ERROR - 2017-05-08 05:08:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 05:08:30 --> Session Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Helper loaded: string_helper
DEBUG - 2017-05-08 05:08:30 --> Session routines successfully run
DEBUG - 2017-05-08 05:08:30 --> User Agent Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Controller Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Helper loaded: form_helper
DEBUG - 2017-05-08 05:08:30 --> Model Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Model Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Config Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Hooks Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Utf8 Class Initialized
DEBUG - 2017-05-08 05:08:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 05:08:30 --> URI Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Router Class Initialized
DEBUG - 2017-05-08 05:08:30 --> Output Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Security Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Input Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 05:08:31 --> Language Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Loader Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Helper loaded: url_helper
DEBUG - 2017-05-08 05:08:31 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 05:08:31 --> Database Driver Class Initialized
ERROR - 2017-05-08 05:08:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 05:08:31 --> Session Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Helper loaded: string_helper
DEBUG - 2017-05-08 05:08:31 --> Session routines successfully run
DEBUG - 2017-05-08 05:08:31 --> User Agent Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Controller Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 05:08:31 --> Helper loaded: form_helper
DEBUG - 2017-05-08 05:08:31 --> Helper loaded: format_helper
DEBUG - 2017-05-08 05:08:31 --> Form Validation Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Model Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Model Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Model Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Model Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Model Class Initialized
DEBUG - 2017-05-08 05:08:31 --> File loaded: application/views/home.php
DEBUG - 2017-05-08 05:08:31 --> Final output sent to browser
DEBUG - 2017-05-08 05:08:31 --> Total execution time: 0.3138
DEBUG - 2017-05-08 05:08:31 --> Config Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Hooks Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Utf8 Class Initialized
DEBUG - 2017-05-08 05:08:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 05:08:31 --> URI Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Router Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Output Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Security Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Input Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 05:08:31 --> Language Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Loader Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Helper loaded: url_helper
DEBUG - 2017-05-08 05:08:31 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 05:08:31 --> Database Driver Class Initialized
ERROR - 2017-05-08 05:08:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 05:08:31 --> Session Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Helper loaded: string_helper
DEBUG - 2017-05-08 05:08:31 --> Session routines successfully run
DEBUG - 2017-05-08 05:08:31 --> User Agent Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Controller Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 05:08:31 --> Helper loaded: form_helper
DEBUG - 2017-05-08 05:08:31 --> Helper loaded: format_helper
DEBUG - 2017-05-08 05:08:31 --> Form Validation Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Model Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Model Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Model Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Model Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Model Class Initialized
DEBUG - 2017-05-08 05:08:31 --> Final output sent to browser
DEBUG - 2017-05-08 05:08:31 --> Total execution time: 0.3440
DEBUG - 2017-05-08 05:09:27 --> Config Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Hooks Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Utf8 Class Initialized
DEBUG - 2017-05-08 05:09:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 05:09:27 --> URI Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Router Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Output Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Security Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Input Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 05:09:27 --> Language Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Loader Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Helper loaded: url_helper
DEBUG - 2017-05-08 05:09:27 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 05:09:27 --> Database Driver Class Initialized
ERROR - 2017-05-08 05:09:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 05:09:27 --> Session Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Helper loaded: string_helper
DEBUG - 2017-05-08 05:09:27 --> Session routines successfully run
DEBUG - 2017-05-08 05:09:27 --> User Agent Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Controller Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 05:09:27 --> Helper loaded: form_helper
DEBUG - 2017-05-08 05:09:27 --> Helper loaded: format_helper
DEBUG - 2017-05-08 05:09:27 --> Form Validation Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Model Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Model Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Model Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Model Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Model Class Initialized
DEBUG - 2017-05-08 05:09:27 --> Final output sent to browser
DEBUG - 2017-05-08 05:09:27 --> Total execution time: 0.3210
DEBUG - 2017-05-08 05:09:28 --> Config Class Initialized
DEBUG - 2017-05-08 05:09:28 --> Hooks Class Initialized
DEBUG - 2017-05-08 05:09:28 --> Utf8 Class Initialized
DEBUG - 2017-05-08 05:09:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 05:09:28 --> URI Class Initialized
DEBUG - 2017-05-08 05:09:28 --> Router Class Initialized
DEBUG - 2017-05-08 05:09:28 --> Output Class Initialized
DEBUG - 2017-05-08 05:09:28 --> Security Class Initialized
DEBUG - 2017-05-08 05:09:28 --> Input Class Initialized
DEBUG - 2017-05-08 05:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 05:09:28 --> Language Class Initialized
DEBUG - 2017-05-08 05:09:28 --> Loader Class Initialized
DEBUG - 2017-05-08 05:09:28 --> Helper loaded: url_helper
DEBUG - 2017-05-08 05:09:29 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 05:09:29 --> Database Driver Class Initialized
ERROR - 2017-05-08 05:09:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 05:09:29 --> Session Class Initialized
DEBUG - 2017-05-08 05:09:29 --> Helper loaded: string_helper
DEBUG - 2017-05-08 05:09:29 --> Session routines successfully run
DEBUG - 2017-05-08 05:09:29 --> User Agent Class Initialized
DEBUG - 2017-05-08 05:09:29 --> Controller Class Initialized
DEBUG - 2017-05-08 05:09:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 05:09:29 --> Helper loaded: form_helper
DEBUG - 2017-05-08 05:09:29 --> Helper loaded: format_helper
DEBUG - 2017-05-08 05:09:29 --> Form Validation Class Initialized
DEBUG - 2017-05-08 05:09:29 --> Model Class Initialized
DEBUG - 2017-05-08 05:09:29 --> Model Class Initialized
DEBUG - 2017-05-08 05:09:29 --> Model Class Initialized
DEBUG - 2017-05-08 05:09:29 --> Model Class Initialized
DEBUG - 2017-05-08 05:09:29 --> Model Class Initialized
DEBUG - 2017-05-08 05:09:29 --> Final output sent to browser
DEBUG - 2017-05-08 05:09:29 --> Total execution time: 0.3429
DEBUG - 2017-05-08 08:29:02 --> Config Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Hooks Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Utf8 Class Initialized
DEBUG - 2017-05-08 08:29:03 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 08:29:03 --> URI Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Router Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Output Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Security Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Input Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 08:29:03 --> Language Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Loader Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Helper loaded: url_helper
DEBUG - 2017-05-08 08:29:03 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 08:29:03 --> Database Driver Class Initialized
ERROR - 2017-05-08 08:29:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 08:29:03 --> Session Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Helper loaded: string_helper
DEBUG - 2017-05-08 08:29:03 --> Session routines successfully run
DEBUG - 2017-05-08 08:29:03 --> User Agent Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Controller Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 08:29:03 --> Config Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Hooks Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Utf8 Class Initialized
DEBUG - 2017-05-08 08:29:03 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 08:29:03 --> URI Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Router Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Output Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Security Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Input Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 08:29:03 --> Language Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Loader Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Helper loaded: url_helper
DEBUG - 2017-05-08 08:29:03 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 08:29:03 --> Database Driver Class Initialized
ERROR - 2017-05-08 08:29:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 08:29:03 --> Session Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Helper loaded: string_helper
DEBUG - 2017-05-08 08:29:03 --> Session routines successfully run
DEBUG - 2017-05-08 08:29:03 --> User Agent Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Controller Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Helper loaded: form_helper
DEBUG - 2017-05-08 08:29:03 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:03 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:03 --> File loaded: application/views/login.php
DEBUG - 2017-05-08 08:29:03 --> Final output sent to browser
DEBUG - 2017-05-08 08:29:03 --> Total execution time: 0.2086
DEBUG - 2017-05-08 08:29:14 --> Config Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Hooks Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Utf8 Class Initialized
DEBUG - 2017-05-08 08:29:14 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 08:29:14 --> URI Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Router Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Output Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Security Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Input Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 08:29:14 --> Language Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Loader Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Helper loaded: url_helper
DEBUG - 2017-05-08 08:29:14 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 08:29:14 --> Database Driver Class Initialized
ERROR - 2017-05-08 08:29:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 08:29:14 --> Session Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Helper loaded: string_helper
DEBUG - 2017-05-08 08:29:14 --> Session routines successfully run
DEBUG - 2017-05-08 08:29:14 --> User Agent Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Controller Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Helper loaded: form_helper
DEBUG - 2017-05-08 08:29:14 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Config Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Hooks Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Utf8 Class Initialized
DEBUG - 2017-05-08 08:29:14 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 08:29:14 --> URI Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Router Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Output Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Security Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Input Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 08:29:14 --> Language Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Loader Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Helper loaded: url_helper
DEBUG - 2017-05-08 08:29:14 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 08:29:14 --> Database Driver Class Initialized
ERROR - 2017-05-08 08:29:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 08:29:14 --> Session Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Helper loaded: string_helper
DEBUG - 2017-05-08 08:29:14 --> Session routines successfully run
DEBUG - 2017-05-08 08:29:14 --> User Agent Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Controller Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 08:29:14 --> Helper loaded: form_helper
DEBUG - 2017-05-08 08:29:14 --> Helper loaded: format_helper
DEBUG - 2017-05-08 08:29:14 --> Form Validation Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:14 --> File loaded: application/views/home.php
DEBUG - 2017-05-08 08:29:14 --> Final output sent to browser
DEBUG - 2017-05-08 08:29:14 --> Total execution time: 0.2984
DEBUG - 2017-05-08 08:29:14 --> Config Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Hooks Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Utf8 Class Initialized
DEBUG - 2017-05-08 08:29:14 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 08:29:14 --> URI Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Router Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Output Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Security Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Input Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 08:29:14 --> Language Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Loader Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Helper loaded: url_helper
DEBUG - 2017-05-08 08:29:14 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 08:29:14 --> Database Driver Class Initialized
ERROR - 2017-05-08 08:29:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 08:29:14 --> Session Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Helper loaded: string_helper
DEBUG - 2017-05-08 08:29:14 --> Session routines successfully run
DEBUG - 2017-05-08 08:29:14 --> User Agent Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Controller Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 08:29:14 --> Helper loaded: form_helper
DEBUG - 2017-05-08 08:29:14 --> Helper loaded: format_helper
DEBUG - 2017-05-08 08:29:14 --> Form Validation Class Initialized
DEBUG - 2017-05-08 08:29:14 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:15 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:15 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:15 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:15 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:15 --> Final output sent to browser
DEBUG - 2017-05-08 08:29:15 --> Total execution time: 0.3399
DEBUG - 2017-05-08 08:29:17 --> Config Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Hooks Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Utf8 Class Initialized
DEBUG - 2017-05-08 08:29:17 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 08:29:17 --> URI Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Router Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Output Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Security Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Input Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 08:29:17 --> Language Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Loader Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Helper loaded: url_helper
DEBUG - 2017-05-08 08:29:17 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 08:29:17 --> Database Driver Class Initialized
ERROR - 2017-05-08 08:29:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 08:29:17 --> Session Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Helper loaded: string_helper
DEBUG - 2017-05-08 08:29:17 --> Session routines successfully run
DEBUG - 2017-05-08 08:29:17 --> User Agent Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Controller Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 08:29:17 --> Helper loaded: form_helper
DEBUG - 2017-05-08 08:29:17 --> Form Validation Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Helper loaded: format_helper
DEBUG - 2017-05-08 08:29:17 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:17 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:17 --> File loaded: application/views/payment.php
DEBUG - 2017-05-08 08:29:17 --> Final output sent to browser
DEBUG - 2017-05-08 08:29:17 --> Total execution time: 0.3392
DEBUG - 2017-05-08 08:29:37 --> Config Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Hooks Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Utf8 Class Initialized
DEBUG - 2017-05-08 08:29:37 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 08:29:37 --> URI Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Router Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Output Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Security Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Input Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 08:29:37 --> Language Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Loader Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Helper loaded: url_helper
DEBUG - 2017-05-08 08:29:37 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 08:29:37 --> Database Driver Class Initialized
ERROR - 2017-05-08 08:29:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 08:29:37 --> Session Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Helper loaded: string_helper
DEBUG - 2017-05-08 08:29:37 --> Session routines successfully run
DEBUG - 2017-05-08 08:29:37 --> User Agent Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Controller Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 08:29:37 --> Helper loaded: form_helper
DEBUG - 2017-05-08 08:29:37 --> Form Validation Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Helper loaded: format_helper
DEBUG - 2017-05-08 08:29:37 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:37 --> Model Class Initialized
DEBUG - 2017-05-08 08:29:37 --> File loaded: application/views/payment_adjust.php
DEBUG - 2017-05-08 08:29:37 --> Final output sent to browser
DEBUG - 2017-05-08 08:29:37 --> Total execution time: 0.3113
DEBUG - 2017-05-08 08:31:07 --> Config Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Hooks Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Utf8 Class Initialized
DEBUG - 2017-05-08 08:31:07 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 08:31:07 --> URI Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Router Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Output Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Security Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Input Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 08:31:07 --> Language Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Loader Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Helper loaded: url_helper
DEBUG - 2017-05-08 08:31:07 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 08:31:07 --> Database Driver Class Initialized
ERROR - 2017-05-08 08:31:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 08:31:07 --> Session Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Helper loaded: string_helper
DEBUG - 2017-05-08 08:31:07 --> Session routines successfully run
DEBUG - 2017-05-08 08:31:07 --> User Agent Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Controller Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 08:31:07 --> Helper loaded: form_helper
DEBUG - 2017-05-08 08:31:07 --> Form Validation Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Helper loaded: format_helper
DEBUG - 2017-05-08 08:31:07 --> Model Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Model Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Model Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Model Class Initialized
DEBUG - 2017-05-08 08:31:07 --> Model Class Initialized
DEBUG - 2017-05-08 08:31:07 --> File loaded: application/views/payment.php
DEBUG - 2017-05-08 08:31:07 --> Final output sent to browser
DEBUG - 2017-05-08 08:31:07 --> Total execution time: 0.3368
DEBUG - 2017-05-08 08:34:42 --> Config Class Initialized
DEBUG - 2017-05-08 08:34:42 --> Hooks Class Initialized
DEBUG - 2017-05-08 08:34:42 --> Utf8 Class Initialized
DEBUG - 2017-05-08 08:34:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 08:34:43 --> URI Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Router Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Output Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Security Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Input Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 08:34:43 --> Language Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Loader Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Helper loaded: url_helper
DEBUG - 2017-05-08 08:34:43 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 08:34:43 --> Database Driver Class Initialized
ERROR - 2017-05-08 08:34:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 08:34:43 --> Session Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Helper loaded: string_helper
DEBUG - 2017-05-08 08:34:43 --> Session routines successfully run
DEBUG - 2017-05-08 08:34:43 --> User Agent Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Controller Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 08:34:43 --> Helper loaded: form_helper
DEBUG - 2017-05-08 08:34:43 --> Form Validation Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Helper loaded: format_helper
DEBUG - 2017-05-08 08:34:43 --> Model Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Model Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Model Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Model Class Initialized
DEBUG - 2017-05-08 08:34:43 --> Model Class Initialized
DEBUG - 2017-05-08 08:34:43 --> File loaded: application/views/payment.php
DEBUG - 2017-05-08 08:34:43 --> Final output sent to browser
DEBUG - 2017-05-08 08:34:43 --> Total execution time: 0.3348
DEBUG - 2017-05-08 08:39:43 --> Config Class Initialized
DEBUG - 2017-05-08 08:39:43 --> Hooks Class Initialized
DEBUG - 2017-05-08 08:39:43 --> Utf8 Class Initialized
DEBUG - 2017-05-08 08:39:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-08 08:39:44 --> URI Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Router Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Output Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Security Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Input Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-08 08:39:44 --> Language Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Loader Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Helper loaded: url_helper
DEBUG - 2017-05-08 08:39:44 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-08 08:39:44 --> Database Driver Class Initialized
ERROR - 2017-05-08 08:39:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-08 08:39:44 --> Session Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Helper loaded: string_helper
DEBUG - 2017-05-08 08:39:44 --> Session routines successfully run
DEBUG - 2017-05-08 08:39:44 --> User Agent Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Controller Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-08 08:39:44 --> Helper loaded: form_helper
DEBUG - 2017-05-08 08:39:44 --> Form Validation Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Helper loaded: format_helper
DEBUG - 2017-05-08 08:39:44 --> Model Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Model Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Model Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Model Class Initialized
DEBUG - 2017-05-08 08:39:44 --> Model Class Initialized
DEBUG - 2017-05-08 08:39:44 --> File loaded: application/views/admin_profile.php
DEBUG - 2017-05-08 08:39:44 --> Final output sent to browser
DEBUG - 2017-05-08 08:39:44 --> Total execution time: 0.3511
