<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-07-23 22:58:09 --> Config Class Initialized
DEBUG - 2017-07-23 22:58:09 --> Hooks Class Initialized
DEBUG - 2017-07-23 22:58:09 --> Utf8 Class Initialized
DEBUG - 2017-07-23 22:58:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-23 22:58:09 --> URI Class Initialized
DEBUG - 2017-07-23 22:58:09 --> Router Class Initialized
DEBUG - 2017-07-23 22:58:09 --> Output Class Initialized
DEBUG - 2017-07-23 22:58:10 --> Security Class Initialized
DEBUG - 2017-07-23 22:58:10 --> Input Class Initialized
DEBUG - 2017-07-23 22:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-23 22:58:10 --> Language Class Initialized
DEBUG - 2017-07-23 22:58:10 --> Loader Class Initialized
DEBUG - 2017-07-23 22:58:10 --> Helper loaded: url_helper
DEBUG - 2017-07-23 22:58:10 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-07-23 22:58:10 --> Database Driver Class Initialized
ERROR - 2017-07-23 22:58:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-07-23 22:58:10 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-07-23 22:58:10 --> Unable to connect to the database
DEBUG - 2017-07-23 22:58:10 --> Session Class Initialized
DEBUG - 2017-07-23 22:58:10 --> Helper loaded: string_helper
DEBUG - 2017-07-23 22:58:10 --> Session routines successfully run
DEBUG - 2017-07-23 22:58:10 --> User Agent Class Initialized
DEBUG - 2017-07-23 22:58:10 --> Controller Class Initialized
DEBUG - 2017-07-23 22:58:10 --> Helper loaded: form_helper
DEBUG - 2017-07-23 22:58:10 --> Model Class Initialized
DEBUG - 2017-07-23 22:58:10 --> Model Class Initialized
ERROR - 2017-07-23 22:58:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-07-23 22:58:10 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-07-23 22:58:10 --> Unable to connect to the database
ERROR - 2017-07-23 22:58:10 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2017-07-23 22:58:10 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2017-07-23 22:58:10 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_result.php 37
DEBUG - 2017-07-23 22:58:10 --> File loaded: application/views/login.php
DEBUG - 2017-07-23 22:58:10 --> Final output sent to browser
DEBUG - 2017-07-23 22:58:10 --> Total execution time: 0.6818
DEBUG - 2017-07-23 22:58:56 --> Config Class Initialized
DEBUG - 2017-07-23 22:58:56 --> Hooks Class Initialized
DEBUG - 2017-07-23 22:58:56 --> Utf8 Class Initialized
DEBUG - 2017-07-23 22:58:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-23 22:58:56 --> URI Class Initialized
DEBUG - 2017-07-23 22:58:56 --> Router Class Initialized
DEBUG - 2017-07-23 22:58:56 --> Output Class Initialized
DEBUG - 2017-07-23 22:58:56 --> Security Class Initialized
DEBUG - 2017-07-23 22:58:56 --> Input Class Initialized
DEBUG - 2017-07-23 22:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-23 22:58:56 --> Language Class Initialized
DEBUG - 2017-07-23 22:58:56 --> Loader Class Initialized
DEBUG - 2017-07-23 22:58:56 --> Helper loaded: url_helper
DEBUG - 2017-07-23 22:58:56 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-07-23 22:58:56 --> Database Driver Class Initialized
ERROR - 2017-07-23 22:58:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-07-23 22:58:56 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-07-23 22:58:56 --> Unable to connect to the database
DEBUG - 2017-07-23 22:58:56 --> Session Class Initialized
DEBUG - 2017-07-23 22:58:56 --> Helper loaded: string_helper
DEBUG - 2017-07-23 22:58:56 --> Session routines successfully run
DEBUG - 2017-07-23 22:58:56 --> User Agent Class Initialized
DEBUG - 2017-07-23 22:58:56 --> Controller Class Initialized
DEBUG - 2017-07-23 22:58:56 --> Helper loaded: form_helper
DEBUG - 2017-07-23 22:58:56 --> Model Class Initialized
DEBUG - 2017-07-23 22:58:56 --> Model Class Initialized
ERROR - 2017-07-23 22:58:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-07-23 22:58:56 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-07-23 22:58:56 --> Unable to connect to the database
ERROR - 2017-07-23 22:58:56 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2017-07-23 22:58:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2017-07-23 22:58:56 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\vonecall_current\distributors\system\database\drivers\mysql\mysql_result.php 37
DEBUG - 2017-07-23 22:58:56 --> File loaded: application/views/login.php
DEBUG - 2017-07-23 22:58:56 --> Final output sent to browser
DEBUG - 2017-07-23 22:58:56 --> Total execution time: 0.0548
