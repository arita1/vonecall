<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-05-04 06:08:28 --> Config Class Initialized
DEBUG - 2017-05-04 06:08:28 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:08:28 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:08:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:08:28 --> URI Class Initialized
DEBUG - 2017-05-04 06:08:28 --> Router Class Initialized
DEBUG - 2017-05-04 06:08:28 --> Output Class Initialized
DEBUG - 2017-05-04 06:08:28 --> Security Class Initialized
DEBUG - 2017-05-04 06:08:28 --> Input Class Initialized
DEBUG - 2017-05-04 06:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:08:28 --> Language Class Initialized
DEBUG - 2017-05-04 06:08:28 --> Loader Class Initialized
DEBUG - 2017-05-04 06:08:28 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:08:28 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:08:28 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:08:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 06:08:28 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 06:08:28 --> Unable to connect to the database
DEBUG - 2017-05-04 06:08:28 --> Session Class Initialized
DEBUG - 2017-05-04 06:08:28 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:08:28 --> Session routines successfully run
DEBUG - 2017-05-04 06:08:28 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:08:28 --> Controller Class Initialized
DEBUG - 2017-05-04 06:08:28 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:08:28 --> Model Class Initialized
DEBUG - 2017-05-04 06:08:28 --> Model Class Initialized
ERROR - 2017-05-04 06:08:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 06:08:28 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 06:08:28 --> Unable to connect to the database
ERROR - 2017-05-04 06:08:28 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2017-05-04 06:08:28 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2017-05-04 06:08:28 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_result.php 37
DEBUG - 2017-05-04 06:09:41 --> Config Class Initialized
DEBUG - 2017-05-04 06:09:41 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:09:41 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:09:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:09:41 --> URI Class Initialized
DEBUG - 2017-05-04 06:09:41 --> Router Class Initialized
DEBUG - 2017-05-04 06:09:41 --> Output Class Initialized
DEBUG - 2017-05-04 06:09:41 --> Security Class Initialized
DEBUG - 2017-05-04 06:09:41 --> Input Class Initialized
DEBUG - 2017-05-04 06:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:09:41 --> Language Class Initialized
DEBUG - 2017-05-04 06:09:41 --> Loader Class Initialized
DEBUG - 2017-05-04 06:09:41 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:09:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:09:41 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:09:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 06:09:41 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 06:09:41 --> Unable to connect to the database
DEBUG - 2017-05-04 06:09:41 --> Session Class Initialized
DEBUG - 2017-05-04 06:09:41 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:09:41 --> Session routines successfully run
DEBUG - 2017-05-04 06:09:41 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:09:41 --> Controller Class Initialized
DEBUG - 2017-05-04 06:09:41 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:09:41 --> Model Class Initialized
DEBUG - 2017-05-04 06:09:41 --> Model Class Initialized
ERROR - 2017-05-04 06:09:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 06:09:41 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 06:09:41 --> Unable to connect to the database
ERROR - 2017-05-04 06:09:41 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2017-05-04 06:09:41 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2017-05-04 06:09:41 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_result.php 37
DEBUG - 2017-05-04 06:09:45 --> Config Class Initialized
DEBUG - 2017-05-04 06:09:45 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:09:45 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:09:45 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:09:45 --> URI Class Initialized
DEBUG - 2017-05-04 06:09:45 --> Router Class Initialized
DEBUG - 2017-05-04 06:09:45 --> Output Class Initialized
DEBUG - 2017-05-04 06:09:45 --> Security Class Initialized
DEBUG - 2017-05-04 06:09:45 --> Input Class Initialized
DEBUG - 2017-05-04 06:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:09:45 --> Language Class Initialized
DEBUG - 2017-05-04 06:09:45 --> Loader Class Initialized
DEBUG - 2017-05-04 06:09:45 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:09:45 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:09:45 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:09:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 06:09:45 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 06:09:45 --> Unable to connect to the database
DEBUG - 2017-05-04 06:09:45 --> Session Class Initialized
DEBUG - 2017-05-04 06:09:45 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:09:45 --> Session routines successfully run
DEBUG - 2017-05-04 06:09:45 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:09:45 --> Controller Class Initialized
DEBUG - 2017-05-04 06:09:45 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:09:45 --> Model Class Initialized
DEBUG - 2017-05-04 06:09:45 --> Model Class Initialized
ERROR - 2017-05-04 06:09:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 06:09:45 --> Severity: Warning  --> mysql_connect(): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 06:09:45 --> Unable to connect to the database
ERROR - 2017-05-04 06:09:45 --> Severity: Warning  --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2017-05-04 06:09:45 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2017-05-04 06:09:45 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_result.php 37
DEBUG - 2017-05-04 06:11:21 --> Config Class Initialized
DEBUG - 2017-05-04 06:11:21 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:11:21 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:11:21 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:11:21 --> URI Class Initialized
DEBUG - 2017-05-04 06:11:21 --> Router Class Initialized
DEBUG - 2017-05-04 06:11:21 --> Output Class Initialized
DEBUG - 2017-05-04 06:11:21 --> Security Class Initialized
DEBUG - 2017-05-04 06:11:21 --> Input Class Initialized
DEBUG - 2017-05-04 06:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:11:21 --> Language Class Initialized
DEBUG - 2017-05-04 06:11:21 --> Loader Class Initialized
DEBUG - 2017-05-04 06:11:21 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:11:21 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:11:21 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:11:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:11:21 --> Session Class Initialized
DEBUG - 2017-05-04 06:11:21 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:11:21 --> Session routines successfully run
DEBUG - 2017-05-04 06:11:21 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:11:21 --> Controller Class Initialized
DEBUG - 2017-05-04 06:11:21 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:11:21 --> Model Class Initialized
DEBUG - 2017-05-04 06:11:21 --> Model Class Initialized
DEBUG - 2017-05-04 06:11:48 --> Config Class Initialized
DEBUG - 2017-05-04 06:11:48 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:11:48 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:11:48 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:11:48 --> URI Class Initialized
DEBUG - 2017-05-04 06:11:48 --> Router Class Initialized
DEBUG - 2017-05-04 06:11:48 --> Output Class Initialized
DEBUG - 2017-05-04 06:11:48 --> Security Class Initialized
DEBUG - 2017-05-04 06:11:48 --> Input Class Initialized
DEBUG - 2017-05-04 06:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:11:48 --> Language Class Initialized
DEBUG - 2017-05-04 06:11:48 --> Loader Class Initialized
DEBUG - 2017-05-04 06:11:48 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:11:48 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:11:48 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:11:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:11:48 --> Session Class Initialized
DEBUG - 2017-05-04 06:11:48 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:11:48 --> Session routines successfully run
DEBUG - 2017-05-04 06:11:48 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:11:48 --> Controller Class Initialized
DEBUG - 2017-05-04 06:11:48 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:11:48 --> Model Class Initialized
DEBUG - 2017-05-04 06:11:48 --> Model Class Initialized
DEBUG - 2017-05-04 06:11:51 --> Config Class Initialized
DEBUG - 2017-05-04 06:11:51 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:11:51 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:11:51 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:11:51 --> URI Class Initialized
DEBUG - 2017-05-04 06:11:51 --> Router Class Initialized
DEBUG - 2017-05-04 06:11:51 --> Output Class Initialized
DEBUG - 2017-05-04 06:11:51 --> Security Class Initialized
DEBUG - 2017-05-04 06:11:51 --> Input Class Initialized
DEBUG - 2017-05-04 06:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:11:51 --> Language Class Initialized
DEBUG - 2017-05-04 06:11:51 --> Loader Class Initialized
DEBUG - 2017-05-04 06:11:51 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:11:51 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:11:51 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:11:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:11:51 --> Session Class Initialized
DEBUG - 2017-05-04 06:11:51 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:11:51 --> Session routines successfully run
DEBUG - 2017-05-04 06:11:51 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:11:51 --> Controller Class Initialized
DEBUG - 2017-05-04 06:11:51 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:11:51 --> Model Class Initialized
DEBUG - 2017-05-04 06:11:51 --> Model Class Initialized
DEBUG - 2017-05-04 06:12:17 --> Config Class Initialized
DEBUG - 2017-05-04 06:12:17 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:12:17 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:12:17 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:12:17 --> URI Class Initialized
DEBUG - 2017-05-04 06:12:17 --> Router Class Initialized
DEBUG - 2017-05-04 06:12:17 --> Output Class Initialized
DEBUG - 2017-05-04 06:12:17 --> Security Class Initialized
DEBUG - 2017-05-04 06:12:17 --> Input Class Initialized
DEBUG - 2017-05-04 06:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:12:17 --> Language Class Initialized
DEBUG - 2017-05-04 06:12:17 --> Loader Class Initialized
DEBUG - 2017-05-04 06:12:17 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:12:17 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:12:17 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:12:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:12:17 --> Session Class Initialized
DEBUG - 2017-05-04 06:12:17 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:12:17 --> Session routines successfully run
DEBUG - 2017-05-04 06:12:17 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:12:17 --> Controller Class Initialized
DEBUG - 2017-05-04 06:12:17 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:12:17 --> Model Class Initialized
DEBUG - 2017-05-04 06:12:17 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:33 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:33 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:33 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:33 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:33 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:33 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:33 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:33 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:33 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:33 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:33 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:33 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:33 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:33 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:33 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:33 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:33 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:33 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:33 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:33 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:33 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:33 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:33 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:33 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:33 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:33 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:33 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:33 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:34 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:34 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:34 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:34 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:34 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:34 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:34 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:34 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:34 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:34 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:34 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:34 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:34 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:34 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:34 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:34 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:34 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:34 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:34 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:34 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:34 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:34 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:34 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:34 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:34 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:34 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:34 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:34 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:34 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:34 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:34 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:34 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:34 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:34 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:34 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:34 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:34 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:34 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:34 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:34 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:34 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:34 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:34 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:34 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:34 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:34 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:34 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:34 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:34 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:34 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:34 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:34 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:34 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:34 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:34 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:34 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:34 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:34 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:34 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:34 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:34 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:34 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:35 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:35 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:35 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:35 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:35 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:35 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:35 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:35 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:35 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:35 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:35 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:35 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:35 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:35 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:35 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:35 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:35 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:35 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:35 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:35 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:35 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:35 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:35 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:35 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:35 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:35 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:35 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:35 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:35 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:35 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:35 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:35 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:35 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:35 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:35 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:35 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:35 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:35 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:35 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:35 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:35 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:35 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:35 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:35 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:35 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:35 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:35 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:35 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:35 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:35 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:35 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:35 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:36 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:36 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:36 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:36 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:36 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:36 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:36 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:36 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:36 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:36 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:36 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:36 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:36 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:36 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:36 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:36 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:36 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:36 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:36 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:36 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:36 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:36 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:36 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:36 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:36 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:36 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:36 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:36 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:36 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:36 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:36 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:36 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:36 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:36 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:36 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:42 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:42 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:42 --> No URI present. Default controller set.
DEBUG - 2017-05-04 06:59:42 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:42 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:42 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:42 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:42 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:42 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:42 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:42 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:42 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:42 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:42 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:42 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:42 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:42 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:42 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:42 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:42 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:42 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:42 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:42 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:42 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:42 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:42 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:42 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:42 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:42 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:42 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:42 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:42 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:42 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:42 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:42 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:42 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:42 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:42 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:42 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:42 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:42 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:42 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:42 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:42 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:43 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:43 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:43 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:43 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:43 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:43 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:43 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:43 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:43 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:43 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:43 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:43 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:43 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:43 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:43 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:43 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:43 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:43 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:43 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:43 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:43 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:43 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:43 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:43 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:43 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:43 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:43 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:43 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:43 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:43 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:43 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:43 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:43 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:43 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:43 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:43 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:43 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:43 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:43 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:43 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:43 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:43 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:43 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:43 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:43 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:43 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:43 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:43 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:43 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:44 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:44 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:44 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:44 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:44 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:44 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:44 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:44 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:44 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:44 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:44 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:44 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:44 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:44 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:44 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:44 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:44 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:44 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:44 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:44 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:44 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:44 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:44 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:44 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:44 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:44 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:44 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:44 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:44 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:44 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:44 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:44 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:44 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:44 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:44 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:44 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:44 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:44 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:44 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:44 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:44 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:44 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:44 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:44 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:44 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:44 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:44 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:44 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:44 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 06:59:45 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:45 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:45 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:45 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:45 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:45 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:45 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:45 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:45 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Helper loaded: form_helper
DEBUG - 2017-05-04 06:59:45 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Model Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Config Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:59:45 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:59:45 --> URI Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Router Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Output Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Security Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Input Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:59:45 --> Language Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Loader Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:59:45 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 06:59:45 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:59:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 06:59:45 --> Session Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Helper loaded: string_helper
DEBUG - 2017-05-04 06:59:45 --> Session routines successfully run
DEBUG - 2017-05-04 06:59:45 --> User Agent Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Controller Class Initialized
DEBUG - 2017-05-04 06:59:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:36 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:36 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:36 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:36 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:36 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:36 --> No URI present. Default controller set.
DEBUG - 2017-05-04 07:00:36 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:36 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:36 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:36 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:36 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:36 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:36 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:36 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:36 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:36 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:36 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:36 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:36 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:36 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:36 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:36 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:37 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:37 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:37 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:37 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:37 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:37 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:37 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:37 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:37 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:37 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:37 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:37 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:37 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:37 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:37 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:37 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:37 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:37 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:37 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:37 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:37 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:37 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:37 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:37 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:37 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:37 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:37 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:37 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:37 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:37 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:37 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:37 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:37 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:37 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:37 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:37 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:37 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:37 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:37 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:37 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:37 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:37 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:37 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:37 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:37 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:37 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:37 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:37 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:37 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:37 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:37 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:37 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:37 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:37 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:37 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:38 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:38 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:38 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:38 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:38 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:38 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:38 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:38 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:38 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:38 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:38 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:38 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:38 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:38 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:38 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:38 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:38 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:38 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:38 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:38 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:38 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:38 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:38 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:38 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:38 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:38 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:38 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:38 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:38 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:38 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:38 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:38 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:38 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:38 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:38 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:38 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:38 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:38 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:38 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:38 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:38 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:38 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:38 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:38 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:38 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:39 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:39 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:39 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:39 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:39 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:39 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:39 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:39 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:39 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:39 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:39 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:39 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:39 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:39 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:39 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:39 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:39 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:39 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:39 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:39 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:39 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:39 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:39 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:39 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:39 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:39 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:39 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:39 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:39 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:39 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:39 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:39 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:39 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:39 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:39 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:39 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:39 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:39 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:40 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:40 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:40 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:40 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:40 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:40 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:40 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:40 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:40 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:40 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:40 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:40 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:40 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:40 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:40 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:40 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:40 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:40 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:40 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:40 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:40 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:40 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:40 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:40 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:40 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:40 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:40 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:40 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:40 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:40 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:40 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:40 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:40 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:40 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:40 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:40 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:40 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:40 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:40 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:40 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:40 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:40 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:41 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:41 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:41 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:41 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:41 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:41 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:41 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:41 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:41 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:41 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:41 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:41 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:41 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:41 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:41 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:41 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:41 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:41 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:41 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:41 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:41 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:41 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:41 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:41 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:41 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:41 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:41 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:41 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:41 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:41 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:41 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:41 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:41 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:41 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:41 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:41 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:41 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:41 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:42 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:42 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:42 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:42 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:42 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:42 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:42 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:42 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:42 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:42 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:42 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:42 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:42 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:42 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:42 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:42 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:42 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:42 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:42 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:42 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:42 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:42 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:42 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:42 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:42 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:42 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:42 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:42 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:42 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:42 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:42 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:42 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:42 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:42 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:42 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:42 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:42 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:42 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:42 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:42 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:43 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:43 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:43 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:43 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:43 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:43 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:43 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:43 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:43 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:43 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:43 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:43 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:43 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:43 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:43 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:43 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:43 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:43 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:43 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:43 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:43 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:43 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:43 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:43 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:43 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:43 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:43 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:43 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:43 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:43 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:43 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:43 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:43 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:43 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:43 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:43 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:43 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:43 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:43 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:43 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:43 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:44 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:44 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:44 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:44 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:44 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:44 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:44 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:44 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:44 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:44 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:44 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:44 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:44 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:44 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:44 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:44 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:44 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:49 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:49 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:49 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:49 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:49 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:49 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:49 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:49 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:49 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:49 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:49 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:49 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:49 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:49 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:49 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:49 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:49 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:49 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:49 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:49 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:49 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:49 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:49 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:49 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:49 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:50 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:50 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:50 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:50 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:50 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:50 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:50 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:50 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:50 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:50 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:50 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:50 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:50 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:50 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:50 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:50 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:50 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:50 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:50 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:50 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:50 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:50 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:50 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:50 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:50 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:50 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:50 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:50 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:50 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:50 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:50 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:50 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:50 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:50 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:50 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:50 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:50 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:50 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:50 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:50 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:50 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:50 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:50 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:50 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:51 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:51 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:51 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:51 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:51 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:51 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:51 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:51 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:51 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:51 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:51 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:51 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:51 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:51 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:51 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:51 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:51 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:51 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:51 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:51 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:51 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:51 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:51 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:51 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:51 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:51 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:51 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:51 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:51 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:51 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:51 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:51 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:51 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:51 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:51 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:51 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:51 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:51 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:51 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:51 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:51 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:51 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:51 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:51 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:51 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:51 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:51 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:52 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:52 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:52 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:52 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:52 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:52 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:52 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:52 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:52 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:52 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:52 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:52 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:52 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:52 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:52 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:52 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:52 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:52 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:52 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:52 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:52 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:52 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:52 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:52 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:52 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:52 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:52 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:52 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:52 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:52 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:52 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:52 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:52 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:52 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:52 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:52 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:52 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:52 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:52 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:53 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:53 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:53 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:53 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:53 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:53 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:53 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:53 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:53 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:53 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:53 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:53 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:53 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:53 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:53 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:53 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:53 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:53 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:53 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:00:53 --> Config Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:00:53 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:00:53 --> URI Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Router Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Output Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Security Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Input Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:00:53 --> Language Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Loader Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:00:53 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:00:53 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:00:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:00:53 --> Session Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:00:53 --> Session routines successfully run
DEBUG - 2017-05-04 07:00:53 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Controller Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:00:53 --> Model Class Initialized
DEBUG - 2017-05-04 07:00:53 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:23 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:23 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:23 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:23 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:23 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:23 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:23 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:23 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:01:23 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:23 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:23 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:24 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:24 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:24 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:24 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:24 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:24 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:01:24 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:24 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:24 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:24 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:24 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:24 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:24 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:24 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:24 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:01:24 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:24 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:24 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:24 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:24 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:24 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:24 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:24 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:24 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:01:24 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:24 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:24 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:24 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:24 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:24 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:24 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:24 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:24 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:01:24 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:24 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:24 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:24 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:24 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:24 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:24 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:24 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:24 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:01:24 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:24 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:24 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:24 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:25 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:25 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:25 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:25 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:25 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:25 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:01:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:25 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:25 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:25 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:25 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:25 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:25 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:25 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:01:25 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:25 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:25 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:25 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:25 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:25 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:25 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:25 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:01:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:25 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:25 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:25 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:25 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:25 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:25 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:25 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:01:25 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:25 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:25 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:25 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:25 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:25 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:25 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:25 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:01:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:25 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:26 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:26 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:26 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:26 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:26 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:26 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:26 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:26 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:01:26 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:26 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:26 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:26 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:26 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:26 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:26 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:26 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:26 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:01:26 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:26 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:26 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:26 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:26 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:26 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:26 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:26 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:26 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:01:26 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:26 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:26 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:26 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:26 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:26 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:26 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:26 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:26 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:01:26 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:26 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:26 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:26 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:26 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:26 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:26 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:26 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:27 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:27 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:01:27 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:27 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:27 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:27 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:27 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:27 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:27 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:27 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:01:27 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:27 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:27 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:27 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:27 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:27 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:27 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:27 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:01:27 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:27 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:27 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:27 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:27 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:27 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:27 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:27 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:01:27 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:27 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:27 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:27 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:27 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:27 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:27 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:27 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:01:27 --> Config Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:01:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:01:27 --> URI Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Router Class Initialized
DEBUG - 2017-05-04 07:01:27 --> Output Class Initialized
DEBUG - 2017-05-04 07:01:28 --> Security Class Initialized
DEBUG - 2017-05-04 07:01:28 --> Input Class Initialized
DEBUG - 2017-05-04 07:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:01:28 --> Language Class Initialized
DEBUG - 2017-05-04 07:01:28 --> Loader Class Initialized
DEBUG - 2017-05-04 07:01:28 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:01:28 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:01:28 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:01:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:01:28 --> Session Class Initialized
DEBUG - 2017-05-04 07:01:28 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:01:28 --> Session routines successfully run
DEBUG - 2017-05-04 07:01:28 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:01:28 --> Controller Class Initialized
DEBUG - 2017-05-04 07:01:28 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:01:28 --> Model Class Initialized
DEBUG - 2017-05-04 07:01:28 --> Model Class Initialized
DEBUG - 2017-05-04 07:05:29 --> Config Class Initialized
DEBUG - 2017-05-04 07:05:29 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:05:29 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:05:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:05:29 --> URI Class Initialized
DEBUG - 2017-05-04 07:05:29 --> Router Class Initialized
DEBUG - 2017-05-04 07:05:29 --> Output Class Initialized
DEBUG - 2017-05-04 07:05:29 --> Security Class Initialized
DEBUG - 2017-05-04 07:05:29 --> Input Class Initialized
DEBUG - 2017-05-04 07:05:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:05:29 --> Language Class Initialized
DEBUG - 2017-05-04 07:05:29 --> Loader Class Initialized
DEBUG - 2017-05-04 07:05:29 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:05:29 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:05:29 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:05:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:05:29 --> Session Class Initialized
DEBUG - 2017-05-04 07:05:29 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:05:29 --> Session routines successfully run
DEBUG - 2017-05-04 07:05:29 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:05:29 --> Controller Class Initialized
DEBUG - 2017-05-04 07:05:29 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:05:29 --> Model Class Initialized
DEBUG - 2017-05-04 07:05:29 --> Model Class Initialized
DEBUG - 2017-05-04 07:05:29 --> File loaded: application/views/login.php
DEBUG - 2017-05-04 07:05:29 --> Final output sent to browser
DEBUG - 2017-05-04 07:05:29 --> Total execution time: 0.2219
DEBUG - 2017-05-04 07:05:45 --> Config Class Initialized
DEBUG - 2017-05-04 07:05:45 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:05:45 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:05:45 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:05:45 --> URI Class Initialized
DEBUG - 2017-05-04 07:05:45 --> Router Class Initialized
DEBUG - 2017-05-04 07:05:45 --> Output Class Initialized
DEBUG - 2017-05-04 07:05:45 --> Security Class Initialized
DEBUG - 2017-05-04 07:05:45 --> Input Class Initialized
DEBUG - 2017-05-04 07:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:05:45 --> Language Class Initialized
DEBUG - 2017-05-04 07:05:45 --> Loader Class Initialized
DEBUG - 2017-05-04 07:05:45 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:05:45 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:05:45 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:05:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:05:45 --> Session Class Initialized
DEBUG - 2017-05-04 07:05:45 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:05:45 --> Session routines successfully run
DEBUG - 2017-05-04 07:05:45 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:05:45 --> Controller Class Initialized
DEBUG - 2017-05-04 07:05:45 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:05:45 --> Model Class Initialized
DEBUG - 2017-05-04 07:05:45 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:05 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:05 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:05 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:05 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:05 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:05 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:05 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:05 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:05 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:05 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:05 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:05 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:05 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:05 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:05 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:05 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:05 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:05 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:05 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:05 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:05 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:06 --> File loaded: application/views/home.php
DEBUG - 2017-05-04 07:06:06 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:06 --> Total execution time: 0.3456
DEBUG - 2017-05-04 07:06:06 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:06 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:06 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:06 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:06 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:06 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:06 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:06 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:06 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:06 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:06 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:06 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:06 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:06 --> Total execution time: 0.3615
DEBUG - 2017-05-04 07:06:14 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:14 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:14 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:14 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:14 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:14 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:14 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:14 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:14 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:14 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:14 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:14 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:14 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:14 --> Total execution time: 0.3471
DEBUG - 2017-05-04 07:06:16 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:16 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:16 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:16 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:16 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:16 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:16 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:16 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:16 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:16 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:16 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:16 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:16 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:16 --> Total execution time: 0.3630
DEBUG - 2017-05-04 07:06:17 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:17 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:17 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:17 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:17 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:17 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:17 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:17 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:17 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:17 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:17 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:17 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:17 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:17 --> Total execution time: 0.3558
DEBUG - 2017-05-04 07:06:22 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:23 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:23 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:23 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:23 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:23 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:23 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:23 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:23 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:23 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:23 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:23 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:23 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:23 --> File loaded: application/views/sub_distributor_manager.php
DEBUG - 2017-05-04 07:06:23 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:23 --> Total execution time: 0.3087
DEBUG - 2017-05-04 07:06:25 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:25 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:25 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:25 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:25 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:25 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:25 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:25 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:25 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:25 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:25 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:25 --> File loaded: application/views/change_password.php
DEBUG - 2017-05-04 07:06:25 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:25 --> Total execution time: 0.3053
DEBUG - 2017-05-04 07:06:27 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:27 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:27 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:27 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:27 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:27 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:27 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:27 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:27 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:27 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:27 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:27 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:27 --> File loaded: application/views/payment.php
DEBUG - 2017-05-04 07:06:27 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:27 --> Total execution time: 0.3737
DEBUG - 2017-05-04 07:06:35 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:35 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:35 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:35 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:35 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:35 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:35 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:35 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:35 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:35 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:35 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:35 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:35 --> File loaded: application/views/payment_adjust.php
DEBUG - 2017-05-04 07:06:35 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:35 --> Total execution time: 0.3683
DEBUG - 2017-05-04 07:06:39 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:39 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:39 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:39 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:39 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:39 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:39 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:39 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:39 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:39 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:39 --> Model Class Initialized
ERROR - 2017-05-04 07:06:39 --> Severity: Notice  --> Undefined variable: option_subdist C:\xampp\htdocs\vonecall\distributors\application\views\reports\sales_report.php 38
ERROR - 2017-05-04 07:06:39 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vonecall\distributors\system\helpers\form_helper.php 331
DEBUG - 2017-05-04 07:06:39 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-04 07:06:39 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:39 --> Total execution time: 0.3211
DEBUG - 2017-05-04 07:06:41 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:41 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:41 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:41 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:41 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:41 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:41 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:41 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:41 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:41 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:41 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:41 --> Model Class Initialized
ERROR - 2017-05-04 07:06:42 --> Severity: Notice  --> Undefined variable: option_subdist C:\xampp\htdocs\vonecall\distributors\application\views\reports\sales_report.php 38
ERROR - 2017-05-04 07:06:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\vonecall\distributors\system\helpers\form_helper.php 331
DEBUG - 2017-05-04 07:06:42 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-04 07:06:42 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:42 --> Total execution time: 0.5131
DEBUG - 2017-05-04 07:06:45 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:45 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:45 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:45 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:45 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:45 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:45 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:45 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:45 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:45 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:45 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:45 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:45 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:45 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-04 07:06:45 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:45 --> Total execution time: 0.3129
DEBUG - 2017-05-04 07:06:47 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:47 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:47 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:47 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:47 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:47 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:47 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:47 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:47 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:47 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:47 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:47 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:47 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:47 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-04 07:06:47 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:47 --> Total execution time: 0.3215
DEBUG - 2017-05-04 07:06:48 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:48 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:48 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:48 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:48 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:48 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:48 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:48 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:48 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:48 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:48 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:48 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:48 --> Model Class Initialized
ERROR - 2017-05-04 07:06:48 --> Could not find the language line "header_title"
ERROR - 2017-05-04 07:06:48 --> Could not find the language line "access_number"
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:48 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:49 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:50 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:51 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:52 --> Config Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:52 --> Hooks Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:52 --> Utf8 Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:52 --> UTF-8 Support Enabled
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:52 --> URI Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:52 --> Router Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:52 --> Output Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:52 --> Security Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:52 --> Input Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:52 --> Global POST and COOKIE data sanitized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:52 --> Language Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:52 --> Loader Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:52 --> Helper loaded: url_helper
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:52 --> Language file loaded: language/english/english_lang.php
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:52 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:52 --> Session Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:52 --> Helper loaded: string_helper
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:52 --> Session routines successfully run
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:52 --> User Agent Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:52 --> Controller Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:52 --> Helper loaded: form_helper
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:52 --> Helper loaded: format_helper
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:52 --> Form Validation Class Initialized
ERROR - 2017-05-04 07:06:52 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:52 --> Model Class Initialized
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:53 --> Model Class Initialized
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:53 --> Model Class Initialized
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:53 --> Model Class Initialized
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:53 --> Model Class Initialized
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:53 --> File loaded: application/views/reports/_reports.php
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:53 --> Final output sent to browser
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:53 --> Total execution time: 0.6277
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:53 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:54 --> Config Class Initialized
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:54 --> Hooks Class Initialized
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:54 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:54 --> UTF-8 Support Enabled
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:54 --> URI Class Initialized
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:54 --> Router Class Initialized
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:54 --> Output Class Initialized
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:54 --> Security Class Initialized
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:54 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:54 --> Global POST and COOKIE data sanitized
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:54 --> Language Class Initialized
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:54 --> Loader Class Initialized
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:54 --> Helper loaded: url_helper
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:54 --> Language file loaded: language/english/english_lang.php
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:54 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 07:06:54 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:55 --> Session Class Initialized
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:55 --> Helper loaded: string_helper
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:55 --> Session routines successfully run
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:55 --> User Agent Class Initialized
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:55 --> Controller Class Initialized
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:55 --> Helper loaded: form_helper
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:55 --> Helper loaded: format_helper
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:55 --> Form Validation Class Initialized
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:55 --> Model Class Initialized
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:55 --> Model Class Initialized
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:55 --> Model Class Initialized
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:06:55 --> Model Class Initialized
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:55 --> Model Class Initialized
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:55 --> File loaded: application/views/reports/_reports.php
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:06:55 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:55 --> Total execution time: 0.7236
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:55 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:06:56 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:06:56 --> File loaded: application/views/popup_access_number.php
DEBUG - 2017-05-04 07:06:56 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:56 --> Total execution time: 8.0530
DEBUG - 2017-05-04 07:06:57 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:57 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:57 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:57 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:57 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:57 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:57 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:57 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:57 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:57 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:57 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:57 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:57 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:57 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-04 07:06:57 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:57 --> Total execution time: 0.3682
DEBUG - 2017-05-04 07:06:58 --> Config Class Initialized
DEBUG - 2017-05-04 07:06:58 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:06:58 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:06:58 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:06:58 --> URI Class Initialized
DEBUG - 2017-05-04 07:06:58 --> Router Class Initialized
DEBUG - 2017-05-04 07:06:58 --> Output Class Initialized
DEBUG - 2017-05-04 07:06:58 --> Security Class Initialized
DEBUG - 2017-05-04 07:06:58 --> Input Class Initialized
DEBUG - 2017-05-04 07:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:06:59 --> Language Class Initialized
DEBUG - 2017-05-04 07:06:59 --> Loader Class Initialized
DEBUG - 2017-05-04 07:06:59 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:06:59 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:06:59 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:06:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:06:59 --> Session Class Initialized
DEBUG - 2017-05-04 07:06:59 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:06:59 --> Session routines successfully run
DEBUG - 2017-05-04 07:06:59 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:06:59 --> Controller Class Initialized
DEBUG - 2017-05-04 07:06:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:06:59 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:06:59 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:06:59 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:06:59 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:59 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:59 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:59 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:59 --> Model Class Initialized
DEBUG - 2017-05-04 07:06:59 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-04 07:06:59 --> Final output sent to browser
DEBUG - 2017-05-04 07:06:59 --> Total execution time: 0.5502
DEBUG - 2017-05-04 07:07:00 --> Config Class Initialized
DEBUG - 2017-05-04 07:07:00 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:07:00 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:07:00 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:07:00 --> URI Class Initialized
DEBUG - 2017-05-04 07:07:00 --> Router Class Initialized
DEBUG - 2017-05-04 07:07:00 --> Output Class Initialized
DEBUG - 2017-05-04 07:07:00 --> Security Class Initialized
DEBUG - 2017-05-04 07:07:00 --> Input Class Initialized
DEBUG - 2017-05-04 07:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:07:00 --> Language Class Initialized
DEBUG - 2017-05-04 07:07:00 --> Loader Class Initialized
DEBUG - 2017-05-04 07:07:00 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:07:00 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:07:00 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:07:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:07:01 --> Session Class Initialized
DEBUG - 2017-05-04 07:07:01 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:07:01 --> Session routines successfully run
DEBUG - 2017-05-04 07:07:01 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:07:01 --> Controller Class Initialized
DEBUG - 2017-05-04 07:07:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:07:01 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:07:01 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:07:01 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:07:01 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:01 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:01 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:01 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:01 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:01 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-04 07:07:01 --> Final output sent to browser
DEBUG - 2017-05-04 07:07:01 --> Total execution time: 0.3806
DEBUG - 2017-05-04 07:07:03 --> Config Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:07:03 --> URI Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Router Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Output Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Security Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Input Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:07:03 --> Language Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Loader Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:07:03 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:07:03 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:07:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:07:03 --> Session Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:07:03 --> Session routines successfully run
DEBUG - 2017-05-04 07:07:03 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Controller Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:07:03 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:07:03 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:07:03 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:03 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:03 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-04 07:07:03 --> Final output sent to browser
DEBUG - 2017-05-04 07:07:03 --> Total execution time: 0.3621
DEBUG - 2017-05-04 07:07:04 --> Config Class Initialized
DEBUG - 2017-05-04 07:07:04 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:07:04 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:07:04 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:07:05 --> URI Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Router Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Output Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Security Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Input Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:07:05 --> Language Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Loader Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:07:05 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:07:05 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:07:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:07:05 --> Session Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:07:05 --> Session routines successfully run
DEBUG - 2017-05-04 07:07:05 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Controller Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:07:05 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:07:05 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:07:05 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:05 --> Model Class Initialized
ERROR - 2017-05-04 07:07:05 --> Could not find the language line "header_title"
ERROR - 2017-05-04 07:07:05 --> Could not find the language line "access_number"
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:05 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:06 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:07 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:08 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:09 --> Config Class Initialized
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:09 --> Hooks Class Initialized
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:09 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:07:09 --> UTF-8 Support Enabled
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:09 --> URI Class Initialized
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:09 --> Router Class Initialized
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:09 --> Output Class Initialized
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:09 --> Security Class Initialized
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:09 --> Input Class Initialized
DEBUG - 2017-05-04 07:07:09 --> Global POST and COOKIE data sanitized
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:09 --> Language Class Initialized
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:09 --> Loader Class Initialized
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:09 --> Helper loaded: url_helper
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:09 --> Language file loaded: language/english/english_lang.php
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:09 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:09 --> Session Class Initialized
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:09 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:07:09 --> Session routines successfully run
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:09 --> User Agent Class Initialized
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:09 --> Controller Class Initialized
DEBUG - 2017-05-04 07:07:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:09 --> Helper loaded: form_helper
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:09 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:09 --> Helper loaded: format_helper
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:10 --> Form Validation Class Initialized
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:10 --> Model Class Initialized
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:10 --> Model Class Initialized
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:10 --> Model Class Initialized
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:10 --> Model Class Initialized
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:10 --> Model Class Initialized
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Could not find the language line "header_title"
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Could not find the language line "country_code"
ERROR - 2017-05-04 07:07:10 --> Could not find the language line "balance"
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:10 --> File loaded: application/views/popup_rate.php
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:10 --> Final output sent to browser
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:10 --> Total execution time: 0.7794
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:10 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:11 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:12 --> Config Class Initialized
DEBUG - 2017-05-04 07:07:12 --> Hooks Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:12 --> Utf8 Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:12 --> UTF-8 Support Enabled
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:12 --> URI Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:12 --> Router Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:12 --> Output Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:12 --> Security Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:12 --> Input Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:12 --> Global POST and COOKIE data sanitized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:12 --> Language Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:12 --> Loader Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:12 --> Helper loaded: url_helper
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:12 --> Language file loaded: language/english/english_lang.php
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:12 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:12 --> Session Class Initialized
DEBUG - 2017-05-04 07:07:12 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:07:12 --> Session routines successfully run
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:12 --> User Agent Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:12 --> Controller Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:12 --> Helper loaded: form_helper
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:12 --> Helper loaded: format_helper
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:12 --> Form Validation Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:12 --> Model Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:12 --> Model Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
DEBUG - 2017-05-04 07:07:12 --> Model Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:12 --> Model Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:12 --> Model Class Initialized
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:12 --> Could not find the language line "header_title"
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:12 --> Could not find the language line "country_code"
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:12 --> Could not find the language line "balance"
ERROR - 2017-05-04 07:07:12 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:13 --> File loaded: application/views/popup_rate.php
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
DEBUG - 2017-05-04 07:07:13 --> Final output sent to browser
DEBUG - 2017-05-04 07:07:13 --> Total execution time: 0.8848
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$state C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 44
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$city C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 45
ERROR - 2017-05-04 07:07:13 --> Severity: Notice  --> Undefined property: stdClass::$access_number C:\xampp\htdocs\vonecall\distributors\application\views\popup_access_number.php 46
DEBUG - 2017-05-04 07:07:13 --> File loaded: application/views/popup_access_number.php
DEBUG - 2017-05-04 07:07:13 --> Final output sent to browser
DEBUG - 2017-05-04 07:07:13 --> Total execution time: 8.6017
DEBUG - 2017-05-04 07:07:17 --> Config Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:07:17 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:07:17 --> URI Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Router Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Output Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Security Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Input Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:07:17 --> Language Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Loader Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:07:17 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:07:17 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:07:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:07:17 --> Session Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:07:17 --> Session routines successfully run
DEBUG - 2017-05-04 07:07:17 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Controller Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:07:17 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:07:17 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:07:17 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:17 --> Model Class Initialized
ERROR - 2017-05-04 07:07:17 --> Could not find the language line "header_title"
ERROR - 2017-05-04 07:07:17 --> Could not find the language line "country_code"
ERROR - 2017-05-04 07:07:17 --> Could not find the language line "balance"
DEBUG - 2017-05-04 07:07:17 --> File loaded: application/views/popup_rate.php
DEBUG - 2017-05-04 07:07:17 --> Final output sent to browser
DEBUG - 2017-05-04 07:07:17 --> Total execution time: 0.4549
DEBUG - 2017-05-04 07:07:21 --> Config Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:07:21 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:07:21 --> URI Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Router Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Output Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Security Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Input Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:07:21 --> Language Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Loader Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:07:21 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:07:21 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:07:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:07:21 --> Session Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:07:21 --> Session routines successfully run
DEBUG - 2017-05-04 07:07:21 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Controller Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:07:21 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:07:21 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:07:21 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:21 --> Model Class Initialized
ERROR - 2017-05-04 07:07:21 --> Could not find the language line "header_title"
ERROR - 2017-05-04 07:07:21 --> Could not find the language line "country_code"
ERROR - 2017-05-04 07:07:21 --> Could not find the language line "balance"
DEBUG - 2017-05-04 07:07:21 --> File loaded: application/views/popup_rate.php
DEBUG - 2017-05-04 07:07:21 --> Final output sent to browser
DEBUG - 2017-05-04 07:07:21 --> Total execution time: 0.4546
DEBUG - 2017-05-04 07:07:25 --> Config Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:07:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:07:25 --> URI Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Router Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Output Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Security Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Input Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:07:25 --> Language Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Loader Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:07:25 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:07:25 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:07:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:07:25 --> Session Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:07:25 --> Session routines successfully run
DEBUG - 2017-05-04 07:07:25 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Controller Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:07:25 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:07:25 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:07:25 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:25 --> Model Class Initialized
ERROR - 2017-05-04 07:07:25 --> Could not find the language line "header_title"
ERROR - 2017-05-04 07:07:25 --> Could not find the language line "country_code"
ERROR - 2017-05-04 07:07:25 --> Could not find the language line "balance"
DEBUG - 2017-05-04 07:07:25 --> File loaded: application/views/popup_rate.php
DEBUG - 2017-05-04 07:07:25 --> Final output sent to browser
DEBUG - 2017-05-04 07:07:25 --> Total execution time: 0.4654
DEBUG - 2017-05-04 07:07:30 --> Config Class Initialized
DEBUG - 2017-05-04 07:07:30 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:07:30 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:07:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:07:30 --> URI Class Initialized
DEBUG - 2017-05-04 07:07:30 --> Router Class Initialized
DEBUG - 2017-05-04 07:07:30 --> Output Class Initialized
DEBUG - 2017-05-04 07:07:30 --> Security Class Initialized
DEBUG - 2017-05-04 07:07:30 --> Input Class Initialized
DEBUG - 2017-05-04 07:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:07:30 --> Language Class Initialized
DEBUG - 2017-05-04 07:07:30 --> Loader Class Initialized
DEBUG - 2017-05-04 07:07:30 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:07:30 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:07:30 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:07:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:07:30 --> Session Class Initialized
DEBUG - 2017-05-04 07:07:30 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:07:30 --> Session routines successfully run
DEBUG - 2017-05-04 07:07:30 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:07:31 --> Controller Class Initialized
DEBUG - 2017-05-04 07:07:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:07:31 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:07:31 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:07:31 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:07:31 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:31 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:31 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:31 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:31 --> Model Class Initialized
ERROR - 2017-05-04 07:07:31 --> Could not find the language line "header_title"
ERROR - 2017-05-04 07:07:31 --> Could not find the language line "country_code"
ERROR - 2017-05-04 07:07:31 --> Could not find the language line "balance"
DEBUG - 2017-05-04 07:07:31 --> File loaded: application/views/popup_rate.php
DEBUG - 2017-05-04 07:07:31 --> Final output sent to browser
DEBUG - 2017-05-04 07:07:31 --> Total execution time: 0.4519
DEBUG - 2017-05-04 07:07:33 --> Config Class Initialized
DEBUG - 2017-05-04 07:07:33 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:07:33 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:07:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:07:33 --> URI Class Initialized
DEBUG - 2017-05-04 07:07:33 --> Router Class Initialized
DEBUG - 2017-05-04 07:07:33 --> Output Class Initialized
DEBUG - 2017-05-04 07:07:33 --> Security Class Initialized
DEBUG - 2017-05-04 07:07:34 --> Input Class Initialized
DEBUG - 2017-05-04 07:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:07:34 --> Language Class Initialized
DEBUG - 2017-05-04 07:07:34 --> Loader Class Initialized
DEBUG - 2017-05-04 07:07:34 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:07:34 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:07:34 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:07:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:07:34 --> Session Class Initialized
DEBUG - 2017-05-04 07:07:34 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:07:34 --> Session routines successfully run
DEBUG - 2017-05-04 07:07:34 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:07:34 --> Controller Class Initialized
DEBUG - 2017-05-04 07:07:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:07:34 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:07:34 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:07:34 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:07:34 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:34 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:34 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:34 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:34 --> Model Class Initialized
ERROR - 2017-05-04 07:07:34 --> Could not find the language line "header_title"
ERROR - 2017-05-04 07:07:34 --> Could not find the language line "country_code"
ERROR - 2017-05-04 07:07:34 --> Could not find the language line "balance"
DEBUG - 2017-05-04 07:07:34 --> File loaded: application/views/popup_rate.php
DEBUG - 2017-05-04 07:07:34 --> Final output sent to browser
DEBUG - 2017-05-04 07:07:34 --> Total execution time: 0.4674
DEBUG - 2017-05-04 07:07:36 --> Config Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:07:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:07:36 --> URI Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Router Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Output Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Security Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Input Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:07:36 --> Language Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Loader Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:07:36 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:07:36 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:07:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:07:36 --> Session Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:07:36 --> Session routines successfully run
DEBUG - 2017-05-04 07:07:36 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Controller Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:07:36 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:07:36 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:07:36 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:36 --> Model Class Initialized
ERROR - 2017-05-04 07:07:36 --> Could not find the language line "header_title"
ERROR - 2017-05-04 07:07:36 --> Could not find the language line "country_code"
ERROR - 2017-05-04 07:07:36 --> Could not find the language line "balance"
DEBUG - 2017-05-04 07:07:36 --> File loaded: application/views/popup_rate.php
DEBUG - 2017-05-04 07:07:36 --> Final output sent to browser
DEBUG - 2017-05-04 07:07:36 --> Total execution time: 0.4704
DEBUG - 2017-05-04 07:07:38 --> Config Class Initialized
DEBUG - 2017-05-04 07:07:38 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:07:38 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:07:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:07:38 --> URI Class Initialized
DEBUG - 2017-05-04 07:07:38 --> Router Class Initialized
DEBUG - 2017-05-04 07:07:38 --> Output Class Initialized
DEBUG - 2017-05-04 07:07:38 --> Security Class Initialized
DEBUG - 2017-05-04 07:07:38 --> Input Class Initialized
DEBUG - 2017-05-04 07:07:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:07:39 --> Language Class Initialized
DEBUG - 2017-05-04 07:07:39 --> Loader Class Initialized
DEBUG - 2017-05-04 07:07:39 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:07:39 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:07:39 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:07:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:07:39 --> Session Class Initialized
DEBUG - 2017-05-04 07:07:39 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:07:39 --> Session routines successfully run
DEBUG - 2017-05-04 07:07:39 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:07:39 --> Controller Class Initialized
DEBUG - 2017-05-04 07:07:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:07:39 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:07:39 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:07:39 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:07:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:39 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:39 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-04 07:07:39 --> Final output sent to browser
DEBUG - 2017-05-04 07:07:39 --> Total execution time: 0.6344
DEBUG - 2017-05-04 07:07:47 --> Config Class Initialized
DEBUG - 2017-05-04 07:07:47 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:07:47 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:07:47 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:07:47 --> URI Class Initialized
DEBUG - 2017-05-04 07:07:47 --> Router Class Initialized
DEBUG - 2017-05-04 07:07:47 --> Output Class Initialized
DEBUG - 2017-05-04 07:07:47 --> Security Class Initialized
DEBUG - 2017-05-04 07:07:47 --> Input Class Initialized
DEBUG - 2017-05-04 07:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:07:47 --> Language Class Initialized
DEBUG - 2017-05-04 07:07:47 --> Loader Class Initialized
DEBUG - 2017-05-04 07:07:47 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:07:47 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:07:47 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:07:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:07:47 --> Session Class Initialized
DEBUG - 2017-05-04 07:07:47 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:07:47 --> Session routines successfully run
DEBUG - 2017-05-04 07:07:47 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:07:47 --> Controller Class Initialized
DEBUG - 2017-05-04 07:07:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:07:47 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:07:47 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:07:48 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:07:48 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:48 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:48 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:48 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:48 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:48 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-04 07:07:48 --> Final output sent to browser
DEBUG - 2017-05-04 07:07:48 --> Total execution time: 0.6107
DEBUG - 2017-05-04 07:07:50 --> Config Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:07:50 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:07:50 --> URI Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Router Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Output Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Security Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Input Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:07:50 --> Language Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Loader Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:07:50 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:07:50 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:07:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:07:50 --> Session Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:07:50 --> Session routines successfully run
DEBUG - 2017-05-04 07:07:50 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Controller Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:07:50 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:07:50 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:07:50 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Model Class Initialized
DEBUG - 2017-05-04 07:07:50 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:17 --> Config Class Initialized
DEBUG - 2017-05-04 07:08:17 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:08:17 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:08:17 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:08:17 --> URI Class Initialized
DEBUG - 2017-05-04 07:08:17 --> Router Class Initialized
DEBUG - 2017-05-04 07:08:17 --> Output Class Initialized
DEBUG - 2017-05-04 07:08:17 --> Security Class Initialized
DEBUG - 2017-05-04 07:08:17 --> Input Class Initialized
DEBUG - 2017-05-04 07:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:08:18 --> Language Class Initialized
DEBUG - 2017-05-04 07:08:18 --> Loader Class Initialized
DEBUG - 2017-05-04 07:08:18 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:08:18 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:08:18 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:08:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:08:18 --> Session Class Initialized
DEBUG - 2017-05-04 07:08:18 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:08:18 --> Session routines successfully run
DEBUG - 2017-05-04 07:08:18 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:08:18 --> Controller Class Initialized
DEBUG - 2017-05-04 07:08:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:08:18 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:08:18 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:08:18 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:08:18 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:18 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:18 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:18 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:18 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:18 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-04 07:08:18 --> Final output sent to browser
DEBUG - 2017-05-04 07:08:18 --> Total execution time: 0.4470
DEBUG - 2017-05-04 07:08:20 --> Config Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:08:20 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:08:20 --> URI Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Router Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Output Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Security Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Input Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:08:20 --> Language Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Loader Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:08:20 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:08:20 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:08:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:08:20 --> Session Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:08:20 --> Session routines successfully run
DEBUG - 2017-05-04 07:08:20 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Controller Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:08:20 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:08:20 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:08:20 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Model Class Initialized
ERROR - 2017-05-04 07:08:20 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\vonecall\distributors\application\controllers\agent.php 1527
DEBUG - 2017-05-04 07:08:20 --> File loaded: application/views/reports/_reports.php
DEBUG - 2017-05-04 07:08:20 --> Final output sent to browser
DEBUG - 2017-05-04 07:08:20 --> Total execution time: 0.4458
DEBUG - 2017-05-04 07:08:20 --> Config Class Initialized
DEBUG - 2017-05-04 07:08:20 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:08:21 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:08:21 --> URI Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Router Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Output Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Security Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Input Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:08:21 --> Language Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Loader Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:08:21 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:08:21 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:08:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:08:21 --> Session Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:08:21 --> Session routines successfully run
DEBUG - 2017-05-04 07:08:21 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Controller Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:08:21 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:08:21 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:08:21 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:21 --> Final output sent to browser
DEBUG - 2017-05-04 07:08:21 --> Total execution time: 0.4331
DEBUG - 2017-05-04 07:08:25 --> Config Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:08:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:08:25 --> URI Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Router Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Output Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Security Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Input Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:08:25 --> Language Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Loader Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:08:25 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:08:25 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:08:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:08:25 --> Session Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:08:25 --> Session routines successfully run
DEBUG - 2017-05-04 07:08:25 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Controller Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:08:25 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:08:25 --> Helper loaded: format_helper
DEBUG - 2017-05-04 07:08:25 --> Form Validation Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:25 --> Model Class Initialized
DEBUG - 2017-05-04 07:08:25 --> File loaded: application/views/sub_distributor_store_manager.php
DEBUG - 2017-05-04 07:08:25 --> Final output sent to browser
DEBUG - 2017-05-04 07:08:25 --> Total execution time: 0.4325
DEBUG - 2017-05-04 07:19:56 --> Config Class Initialized
DEBUG - 2017-05-04 07:19:56 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:19:56 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:19:56 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:19:56 --> URI Class Initialized
DEBUG - 2017-05-04 07:19:56 --> Router Class Initialized
DEBUG - 2017-05-04 07:19:56 --> Output Class Initialized
DEBUG - 2017-05-04 07:19:56 --> Security Class Initialized
DEBUG - 2017-05-04 07:19:56 --> Input Class Initialized
DEBUG - 2017-05-04 07:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:19:56 --> Language Class Initialized
DEBUG - 2017-05-04 07:19:56 --> Loader Class Initialized
DEBUG - 2017-05-04 07:19:56 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:19:56 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:19:56 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:19:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:19:56 --> Session Class Initialized
DEBUG - 2017-05-04 07:19:56 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:19:56 --> A session cookie was not found.
DEBUG - 2017-05-04 07:19:56 --> Session routines successfully run
DEBUG - 2017-05-04 07:19:56 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:19:56 --> Controller Class Initialized
DEBUG - 2017-05-04 07:19:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-05-04 07:19:56 --> Config Class Initialized
DEBUG - 2017-05-04 07:19:56 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:19:56 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:19:56 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:19:56 --> URI Class Initialized
DEBUG - 2017-05-04 07:19:57 --> Router Class Initialized
DEBUG - 2017-05-04 07:19:57 --> Output Class Initialized
DEBUG - 2017-05-04 07:19:57 --> Security Class Initialized
DEBUG - 2017-05-04 07:19:57 --> Input Class Initialized
DEBUG - 2017-05-04 07:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:19:57 --> Language Class Initialized
DEBUG - 2017-05-04 07:19:57 --> Loader Class Initialized
DEBUG - 2017-05-04 07:19:57 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:19:57 --> Language file loaded: language/english/english_lang.php
DEBUG - 2017-05-04 07:19:57 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:19:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vonecall\distributors\system\database\drivers\mysql\mysql_driver.php 73
DEBUG - 2017-05-04 07:19:57 --> Session Class Initialized
DEBUG - 2017-05-04 07:19:57 --> Helper loaded: string_helper
DEBUG - 2017-05-04 07:19:57 --> Session routines successfully run
DEBUG - 2017-05-04 07:19:57 --> User Agent Class Initialized
DEBUG - 2017-05-04 07:19:57 --> Controller Class Initialized
DEBUG - 2017-05-04 07:19:57 --> Helper loaded: form_helper
DEBUG - 2017-05-04 07:19:57 --> Model Class Initialized
DEBUG - 2017-05-04 07:19:57 --> Model Class Initialized
DEBUG - 2017-05-04 07:19:57 --> File loaded: application/views/login.php
DEBUG - 2017-05-04 07:19:57 --> Final output sent to browser
DEBUG - 2017-05-04 07:19:57 --> Total execution time: 0.3397
